"""Offline tests: no browser, external API or applicant submissions."""
import tempfile
import io
import json
import unittest
import asyncio
import sys
import types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

mysql_stub = types.ModuleType("mysql")
mysql_connector_stub = types.ModuleType("mysql.connector")
mysql_connector_stub.connect = Mock()
mysql_stub.connector = mysql_connector_stub
sys.modules.setdefault("mysql", mysql_stub)
sys.modules.setdefault("mysql.connector", mysql_connector_stub)

dotenv_stub = types.ModuleType("dotenv")
dotenv_stub.load_dotenv = Mock()
sys.modules.setdefault("dotenv", dotenv_stub)

playwright_stub = types.ModuleType("playwright")
playwright_async_stub = types.ModuleType("playwright.async_api")
playwright_async_stub.async_playwright = Mock()
playwright_sync_stub = types.ModuleType("playwright.sync_api")
playwright_sync_stub.sync_playwright = Mock()
playwright_stub.async_api = playwright_async_stub
playwright_stub.sync_api = playwright_sync_stub
sys.modules.setdefault("playwright", playwright_stub)
sys.modules.setdefault("playwright.async_api", playwright_async_stub)
sys.modules.setdefault("playwright.sync_api", playwright_sync_stub)

import recruit_manual as flow
flow.update_job_processing_status = Mock()
flow.update_linkedin_havesting_status = Mock()


class CacheTests(unittest.TestCase):
    def test_manual_and_parsed_applicant_snapshot_routes(self):
        self.assertTrue(flow.is_applicant_snapshot("https://tenant/ApplicantProfiles/snapshot/abc"))
        self.assertTrue(flow.is_applicant_snapshot("https://tenant/applicant_profiles/snapshot/abc"))
        self.assertFalse(flow.is_applicant_snapshot("https://tenant/applicant_profiles/add_applicant"))

    def test_bad_store_is_not_silently_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "profiles.json"
            path.write_text("[]")
            with self.assertRaises(ValueError):
                flow.read_store(path)

    def test_india_is_detected_from_current_linkedin_header_location(self):
        raw = {
            "public_sections": [
                "Jane Doe\nSoftware Engineer\nMumbai, Maharashtra, India\n"
                "About\nExperienced engineer"
            ]
        }
        self.assertTrue(flow.is_currently_in_india({}, raw))

    def test_india_is_detected_from_a_state_even_without_country(self):
        raw = {
            "public_sections": [
                "Jane Doe\nSoftware Engineer\nHyderabad, Telangana\n"
                "About\nExperienced engineer"
            ]
        }
        self.assertTrue(flow.is_currently_in_india({}, raw))

    def test_india_in_past_experience_does_not_override_current_location(self):
        raw = {
            "public_sections": [
                "Jane Doe\nToronto, Ontario, Canada\nAbout\n"
                "Experience\nPosition title\nEngineer\n"
                "Position location\nMumbai, India"
            ]
        }
        profile = {"location": "Toronto, Ontario, Canada", "country": "Canada"}
        self.assertFalse(flow.is_currently_in_india(profile, raw))


class LocalAITests(unittest.TestCase):
    def test_auto_selects_available_key_or_local(self):
        from url import extraction_settings
        for key, expected in (("", "ollama"), ("your_key_here", "ollama"), ("test-key", "openai")):
            with patch.dict("os.environ", {"AI_PROVIDER": "auto", "OPENAI_API_KEY": key}, clear=True):
                self.assertEqual(extraction_settings()[0], expected)

    def test_openai_failure_falls_back_to_local_in_auto_mode(self):
        import sys
        from url import build_skill_set
        extracted = {"first_name": "Test", "last_name": "Person", "city": None,
                     "state": None, "country": None,
                     "city_location_validated": False, "skills": []}
        response = {"message": {"content": json.dumps(extracted)}}
        failing_client = SimpleNamespace(OpenAI=Mock(side_effect=RuntimeError("service unavailable")))
        with patch.dict("os.environ", {"AI_PROVIDER": "auto", "OPENAI_API_KEY": "test-key"}, clear=True), \
                patch.dict(sys.modules, {"openai": failing_client}), \
                patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(response).encode())):
            self.assertEqual(build_skill_set({"public_sections": ["Test Person"]}), extracted)

    def test_local_provider_requires_no_key_and_validates_evidence(self):
        from url import build_skill_set
        extracted = {
            "first_name": "Test", "last_name": "Person", "city": None, "state": None,
            "country": None, "city_location_validated": False,
            "skills": [{"skill": "Example engineering", "basis": "explicit",
                        "source": "summary", "evidence": "Example engineering"}],
        }
        response = {"message": {"content": json.dumps(extracted)}}
        with patch.dict("os.environ", {"AI_PROVIDER": "ollama"}, clear=True), \
                patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(response).encode())) as call:
            result = build_skill_set({"public_sections": ["Test Person: Example engineering"]})
            self.assertEqual(result, extracted)
            self.assertEqual(call.call_args.args[0].full_url, "http://127.0.0.1:11434/api/chat")

    def test_ai_city_validation_requires_profile_city_and_location_match(self):
        from url import build_skill_set

        extracted = {
            "first_name": "Jane",
            "last_name": "Doe",
            "city": "New York",
            "state": "New York",
            "country": "United States",
            "city_location_validated": True,
            "skills": [],
        }
        response = {"message": {"content": json.dumps(extracted)}}
        raw = {
            "public_sections": [
                "Jane Doe\nNew York, New York, United States\nExperience\nAnalyst"
            ]
        }
        with patch.dict("os.environ", {"AI_PROVIDER": "ollama"}, clear=True), \
                patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(response).encode())):
            result = build_skill_set(raw)

        self.assertTrue(result["city_location_validated"])
        self.assertEqual(result["city"], "New York")
        self.assertEqual(result["country"], "United States")

        extracted["city"] = "Boston"
        response = {"message": {"content": json.dumps(extracted)}}
        with patch.dict("os.environ", {"AI_PROVIDER": "ollama"}, clear=True), \
                patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(response).encode())):
            result = build_skill_set(raw)

        self.assertFalse(result["city_location_validated"])
        self.assertEqual(result["city"], "New York")

        extracted["city"] = "New York"
        extracted["country"] = "Canada"
        response = {"message": {"content": json.dumps(extracted)}}
        with patch.dict("os.environ", {"AI_PROVIDER": "ollama"}, clear=True), \
                patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(response).encode())):
            result = build_skill_set(raw)

        self.assertTrue(result["city_location_validated"])

        extracted["state"] = "Ontario"
        response = {"message": {"content": json.dumps(extracted)}}
        with patch.dict("os.environ", {"AI_PROVIDER": "ollama"}, clear=True), \
                patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(response).encode())):
            result = build_skill_set(raw)

        self.assertFalse(result["city_location_validated"])

    def test_local_hallucinated_evidence_rejected(self):
        from url import build_skill_set
        extracted = {
            "first_name": "Test", "last_name": "Person", "city": None, "state": None,
            "country": None, "city_location_validated": False,
            "skills": [{"skill": "Imagined skill", "basis": "explicit",
                        "source": "summary", "evidence": "Not present in input"}],
        }
        response = {"message": {"content": json.dumps(extracted)}}
        with patch.dict("os.environ", {"AI_PROVIDER": "ollama"}, clear=True), \
                patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(response).encode())):
            with self.assertRaises(ValueError):
                build_skill_set({"public_sections": ["Test Person"]})


class TitleCleaningTests(unittest.TestCase):
    def test_build_title_mapping_preserves_original_keys(self):
        with patch.object(flow, "clean_job_title", side_effect=["Senior Python Developer", "Lead Data Engineer"]):
            result = flow.build_title_mapping(["sr python dev", "lead data engg"])
        self.assertEqual(result, {
            "sr python dev": "Senior Python Developer",
            "lead data engg": "Lead Data Engineer",
        })


class PipelineTests(unittest.IsolatedAsyncioTestCase):
    async def test_job_list_location_is_used_when_detail_location_is_empty(self):
        jobs = {}
        api = SimpleNamespace(
            discover_jobs=AsyncMock(return_value=["job-1"]),
            job_code_for=lambda url: url,
            job_title=AsyncMock(return_value="Engineer"),
            job_location=AsyncMock(return_value=""),
            generate_location_variants=lambda location, business_unit: [location],
            JOB_METADATA={
                "job-1": {
                    "location": "Toronto, Ontario",
                    "business_unit": "Canada",
                    "date_posted": "Today",
                }
            },
            save_state=Mock(),
        )
        args = SimpleNamespace(job_url=None, jobs_limit=25, search_only=False)

        with patch.object(flow, "clean_job_title", return_value="Engineer"), \
                patch.object(
                    flow,
                    "clean_job_location",
                    return_value="Toronto, Ontario, Canada",
                ) as clean_location:
            await flow.produce_jobs(
                api, args, None, jobs, {}, Path("unused"), asyncio.Queue(), []
            )

        clean_location.assert_called_once_with("Toronto, Ontario")
        self.assertEqual(jobs["job-1"]["location"], "Toronto, Ontario, Canada")
        self.assertEqual(
            jobs["job-1"]["location_variants"],
            ["Toronto, Ontario, Canada"],
        )

    async def test_cached_job_uses_job_list_location_when_cached_location_missing(self):
        jobs = {
            "job-1": {
                "url": "job-1",
                "code": "job-1",
                "title": "Stored Title",
                "location": "",
            }
        }
        api = SimpleNamespace(
            discover_jobs=AsyncMock(return_value=["job-1"]),
            job_code_for=lambda url: url,
            job_title=AsyncMock(),
            job_location=AsyncMock(),
            generate_location_variants=lambda location, business_unit: [location],
            JOB_METADATA={
                "job-1": {
                    "location": "Toronto, Ontario",
                    "business_unit": "Canada",
                    "date_posted": "Today",
                }
            },
            save_state=Mock(),
        )
        args = SimpleNamespace(job_url=None, jobs_limit=25, search_only=False)

        with patch.object(flow, "clean_job_title", return_value="Stored Title"), \
                patch.object(
                    flow,
                    "clean_job_location",
                    return_value="Toronto, Ontario, Canada",
                ) as clean_location:
            await flow.produce_jobs(
                api, args, None, jobs, {}, Path("unused"), asyncio.Queue(), []
            )

        clean_location.assert_called_once_with("Toronto, Ontario")
        self.assertEqual(jobs["job-1"]["location"], "Toronto, Ontario, Canada")
        self.assertEqual(
            jobs["job-1"]["location_variants"],
            ["Toronto, Ontario, Canada"],
        )

    async def test_collector_finishes_while_consumer_waits(self):
        queue = asyncio.Queue()
        jobs = {}
        api = SimpleNamespace(discover_jobs=AsyncMock(return_value=["one", "two", "three"]),
                              job_code_for=lambda url: url, job_title=AsyncMock(return_value="Title"),
                              job_location=AsyncMock(return_value="City"), save_state=Mock())
        api.generate_location_variants = lambda location, business_unit: [location]
        args = SimpleNamespace(job_url=None, jobs_limit=25, search_only=False)
        blocked = asyncio.Event()
        async def slow_consumer():
            await queue.get()
            await blocked.wait()
        consumer = asyncio.create_task(slow_consumer())
        try:
            await asyncio.wait_for(flow.produce_jobs(api, args, None, jobs, {},
                                                    Path("unused"), queue, []), timeout=2)
            self.assertEqual(len(jobs), 3)
            self.assertFalse(consumer.done())
        finally:
            blocked.set()
            await consumer

    async def test_collector_continues_after_one_job_error(self):
        jobs, failures = {}, []
        api = SimpleNamespace(discover_jobs=AsyncMock(return_value=["bad", "good"]),
                              job_code_for=lambda url: url,
                              job_title=AsyncMock(side_effect=[ValueError("bad title"), "Title"]),
                              job_location=AsyncMock(return_value="City"),
                              generate_location_variants=lambda location, business_unit: [location],
                              JOB_METADATA={"good": {"business_unit": "BU", "date_posted": "2 days ago"}},
                              save_state=Mock())
        args = SimpleNamespace(job_url=None, jobs_limit=25, search_only=False)
        with patch.object(flow, "clean_job_title", return_value="Clean Title"):
            await flow.produce_jobs(api, args, None, jobs, {}, Path("unused"), asyncio.Queue(), failures)
        self.assertEqual(list(jobs), ["good"])
        self.assertEqual(failures, ["bad"])
        self.assertEqual(jobs["good"]["location_variants"], ["City"])

    async def test_stored_job_is_reused_without_re_extraction(self):
        api = SimpleNamespace(discover_jobs=AsyncMock(return_value=["j1"]),
                              job_code_for=lambda url: url,
                              job_title=AsyncMock(), job_location=AsyncMock(),
                              generate_location_variants=lambda location, business_unit: [location],
                              JOB_METADATA={"j1": {"business_unit": "Ops", "date_posted": "Today"}},
                              save_state=Mock())
        jobs = {"j1": {"url": "j1", "code": "j1", "title": "Stored Title",
                       "location": "Stored City", "extracted_at": 1}}
        queue = asyncio.Queue()
        args = SimpleNamespace(job_url=None, jobs_limit=25, search_only=False)
        with patch.object(flow, "clean_job_title", return_value="Stored Title"), \
                patch.object(flow, "clean_job_location", side_effect=lambda location: location):
            await flow.produce_jobs(api, args, None, jobs, {}, Path("unused"), queue, [])
        api.job_title.assert_not_called()
        api.job_location.assert_not_called()
        queued = await queue.get()
        self.assertEqual(queued["title"], "Stored Title")
        self.assertEqual(queued["date_posted"], "Today")
        self.assertEqual(queued["business_unit"], "Ops")

    def setUp(self):
        self.url = "https://www.linkedin.com/talent/profile/test-person"
        self.args = SimpleNamespace(limit=20, search_only=False, location=None)
        self.api = SimpleNamespace(
            save_state=Mock(), ROOT=Path("."),
            generate_location_variants=lambda location, business_unit: ["City, State, Country"],
        )
        self.job = {
            "code": "J1", "url": "https://example.test/job/1",
            "title": "sr python dev", "cleaned_title": "Senior Python Developer",
            "business_unit": "Engineering", "date_posted": "2026-09-29",
        }
        self.history = {"J1": {"status": "pending", "profiles": [self.url]}}
        self.profiles = {self.url: {
            "url": self.url, "job_codes": ["J1"], "status": "extracted",
            "raw": {"public_sections": ["Test Person"]},
            "profile": {"first_name": "Test", "last_name": "Person", "skills": []},
            "resume_path": str(Path(__file__).resolve()),
        }}
        self.persist = Mock()

    async def run_job(self):
        await flow.process_job(self.api, self.args, None, None, None,
                               self.job, self.profiles, self.history,
                               Path("unused_history.json"), self.persist)

    async def test_cached_profile_is_not_scraped_or_sent_to_ai_again(self):
        async def saved(page, row, api, persist):
            row["status"] = "saved"
        with patch.object(flow, "extract_profile", AsyncMock()) as extract, \
                patch.object(flow, "create_applicant", AsyncMock(side_effect=saved)), \
                patch("url.build_skill_set") as ai:
            await self.run_job()
            extract.assert_not_called()
            ai.assert_not_called()
        self.assertEqual(self.history["J1"]["status"], "completed")

    async def test_uncertain_save_is_not_retried(self):
        self.profiles[self.url]["status"] = "review_required"
        with patch.object(flow, "create_applicant", AsyncMock()) as create:
            with self.assertRaises(RuntimeError):
                await self.run_job()
            create.assert_not_called()
        self.assertEqual(self.history["J1"]["status"], "pending")

    async def test_error_after_save_stays_uncertain(self):
        async def timeout(page, row, api, persist):
            row["status"] = "saving"
            raise RuntimeError("save timed out")
        with patch.object(flow, "create_applicant", AsyncMock(side_effect=timeout)):
            with self.assertRaises(RuntimeError):
                await self.run_job()
        self.assertEqual(self.profiles[self.url]["status"], "review_required")

    async def test_missing_resume_file_is_rebuilt_from_the_stored_profile(self):
        row = self.profiles[self.url]
        row.pop("resume_path")

        async def saved(page, row, api, persist):
            row["status"] = "saved"

        page = SimpleNamespace(context=object())
        with patch.object(flow, "extract_profile", AsyncMock()) as extract, \
                patch("url.build_skill_set") as ai, \
                patch.object(flow, "write_resume_pdf", AsyncMock()) as pdf, \
                patch.object(flow, "create_applicant", AsyncMock(side_effect=saved)):
            await flow.process_job(self.api, self.args, None, page, None,
                                   self.job, self.profiles, self.history,
                                   Path("unused_history.json"), self.persist)
            extract.assert_not_called()
            ai.assert_not_called()
            pdf.assert_awaited_once()
        self.assertTrue(self.profiles[self.url]["resume_path"].endswith(".pdf"))

    async def test_confirmed_applicant_is_skipped_across_jobs(self):
        self.profiles[self.url]["status"] = "saved"
        self.profiles[self.url]["job_codes"] = ["J0"]
        with patch.object(flow, "create_applicant", AsyncMock()) as create:
            await self.run_job()
            create.assert_not_called()
        self.assertEqual(self.profiles[self.url]["job_codes"], ["J0", "J1"])

    async def test_india_based_profile_is_not_used_to_create_applicant(self):
        profile = self.profiles[self.url]["profile"]
        profile.update({
            "city": "Mumbai",
            "state": "Maharashtra",
            "country": "India",
            "location": "Mumbai, Maharashtra, India",
        })
        with patch.object(flow, "create_applicant", AsyncMock()) as create, \
                patch.object(flow, "write_resume_pdf", AsyncMock()) as write_resume:
            await self.run_job()

        create.assert_not_awaited()
        write_resume.assert_not_awaited()
        self.assertEqual(self.profiles[self.url]["status"], "skipped_india_location")


    async def test_job_metadata_is_copied_to_profile_row(self):
        async def saved(page, row, api, persist, code=None):
            row["status"] = "saved"
        with patch.object(flow, "create_applicant", AsyncMock(side_effect=saved)):
            await self.run_job()
        row = self.profiles[self.url]
        self.assertEqual(row["job_title"], "sr python dev")
        self.assertEqual(row["cleaned_job_title"], "Senior Python Developer")
        self.assertEqual(row["business_unit"], "Engineering")
        self.assertEqual(row["date_posted"], "2026-09-29")
        self.assertEqual(row["title_mapping"]["sr python dev"], "Senior Python Developer")


class PublicProfileTests(unittest.TestCase):
    def test_owner_public_url_wins_over_other_people(self):
        text = ("John Callum McDaniel\nVirginia Tech \u00b7 Richmond, Virginia, United States\n"
                "People also viewed\nhttps://www.linkedin.com/in/someone-else-1234\n"
                "Personal Information\nJohn Callum's profile\n"
                "https://www.linkedin.com/in/john-callum-mcdaniel-0aa02b1b7")
        self.assertEqual(flow.find_public_profile_url(text, "John Callum McDaniel"),
                         "https://www.linkedin.com/in/john-callum-mcdaniel-0aa02b1b7")

    def test_section_urls_are_not_profile_urls(self):
        text = "Jane Doe\nhttps://www.linkedin.com/in/jane-doe/details/experience"
        self.assertEqual(flow.find_public_profile_url(text, "Jane Doe"), "")

    def test_missing_name_still_yields_a_candidate(self):
        text = "https://www.linkedin.com/in/solo-1234"
        self.assertEqual(flow.find_public_profile_url(text, ""),
                         "https://www.linkedin.com/in/solo-1234")


class ResumeTests(unittest.TestCase):
    def test_resume_carries_the_required_applicant_details(self):
        profile = {"first_name": "John", "last_name": "McDaniel", "city": "Richmond",
                   "state": "Virginia", "job_title": "Security Analyst",
                   "skills": [{"skill": "Risk assessment"}],
                   "certifications": ["EXAM-123\nIssuer"]}
        document = flow.render_resume_html(
            profile, "https://www.linkedin.com/talent/profile/abc",
            "https://www.linkedin.com/in/john-mcdaniel")
        for expected in ("John", "McDaniel", "Richmond, Virginia",
                         "https://www.linkedin.com/in/john-mcdaniel",
                         "Risk assessment", "EXAM-123"):
            self.assertIn(expected, document)


class JobLocationFieldTests(unittest.IsolatedAsyncioTestCase):
    def test_dc_profile_location_does_not_infer_canada(self):
        profile = {
            "city": "Washington",
            "state": "District of Columbia",
            "country": "",
        }

        flow.ensure_profile_location(profile, {})

        self.assertEqual(profile["state"], "District of Columbia")
        self.assertEqual(profile["country"], "")

    async def test_job_city_state_override_and_city_validation(self):
        self.assertEqual(
            flow._job_city_state("Alpharetta, Georgia, United States"),
            ("Alpharetta", "Georgia"),
        )
        self.assertEqual(
            flow._job_city_state("Suresh Kotturi, B.Comm, United States"),
            ("", ""),
        )
        self.assertEqual(
            flow._job_city_state("abcdefghijklmnop, Georgia, United States"),
            ("abcdefghijklmnop", "Georgia"),
        )
        self.assertEqual(
            flow._job_city_state("Georgia, United States"),
            ("", "Georgia"),
        )
        self.assertEqual(
            flow._job_city_state("Ontario, Canada"),
            ("", "Ontario"),
        )

    async def test_ai_validated_profile_city_is_preferred(self):
        page = Mock()
        row = {
            "location": "Alpharetta, Georgia, United States",
            "business_unit": "Canada",
            "profile": {
                "city": "New York",
                "city_location_validated": True,
                "state": "Virginia",
                "country": "Canada",
            },
        }
        with patch.object(
            flow,
            "set_input_by_selectors",
            new=AsyncMock(return_value=True),
        ) as set_input, patch.object(
            flow, "detect_country_selector", new=AsyncMock(return_value=None)
        ):
            await flow.apply_job_location_before_save(page, row)

        self.assertEqual(set_input.await_args_list[0].args[2], "New York")
        self.assertEqual(set_input.await_args_list[1].args[2], "Virginia")

    async def test_valid_profile_city_is_used_without_ai_validation_flag(self):
        page = Mock()
        row = {
            "location": "Alpharetta, Georgia, United States",
            "profile": {"city": "Richmond", "city_location_validated": False},
        }
        with patch.object(
            flow,
            "set_input_by_selectors",
            new=AsyncMock(return_value=True),
        ) as set_input, patch.object(
            flow, "detect_country_selector", new=AsyncMock(return_value=None)
        ):
            await flow.apply_job_location_before_save(page, row)

        self.assertEqual(set_input.await_args_list[0].args[2], "Richmond")

    async def test_job_city_state_country_are_used_when_profile_city_is_invalid(self):
        page = Mock()
        row = {
            "location": "Alpharetta, Georgia, United States",
            "profile": {"city": "abcdefghijklmnopqrs"},
        }
        with patch.object(
            flow,
            "set_input_by_selectors",
            new=AsyncMock(return_value=True),
        ) as set_input, patch.object(
            flow, "detect_country_selector", new=AsyncMock(return_value=None)
        ):
            await flow.apply_job_location_before_save(page, row)

        self.assertEqual(set_input.await_args_list[0].args[2], "Alpharetta")
        self.assertEqual(set_input.await_args_list[1].args[2], "Georgia")

    async def test_profile_city_is_filled_when_job_location_is_missing(self):
        page = Mock()
        row = {"profile": {"city": "Richmond", "state": "Virginia"}}
        with patch.object(
            flow,
            "set_input_by_selectors",
            new=AsyncMock(return_value=True),
        ) as set_input, patch.object(
            flow, "detect_country_selector", new=AsyncMock(return_value=None)
        ):
            await flow.apply_job_location_before_save(page, row)

        self.assertEqual(
            [call.args[2] for call in set_input.await_args_list],
            ["Richmond", "Virginia"],
        )

    async def test_invalid_profile_city_falls_back_to_job_location(self):
        city_field = Mock()
        city_field.count = AsyncMock(return_value=1)
        city_field.input_value = AsyncMock(return_value="Cindy Chiang")
        city_field.evaluate = AsyncMock(return_value="")
        city_field.fill = AsyncMock()
        city_field.blur = AsyncMock()
        page = Mock()
        page.locator.return_value.first = city_field

        row = {
            "location": "Alpharetta, Georgia, United States",
            "profile": {
                "city": "Cindy Chiang",
                "state": "PhD",
                "country": "United States",
            },
        }
        with patch.object(
            flow, "validate_city_location", return_value=False
        ) as validate, patch.object(
            flow, "set_input_by_selectors", new=AsyncMock(return_value=True)
        ) as set_input, patch.object(
            flow, "detect_country_selector", new=AsyncMock(return_value=None)
        ):
            await flow.validate_ceipal_city_before_save(page, row, "profile")

        validate.assert_called_once_with("Cindy Chiang, PhD, United States")
        city_field.fill.assert_awaited_once_with("Alpharetta")
        city_field.blur.assert_awaited_once()
        self.assertEqual(set_input.await_args.args[2], "Georgia")

    async def test_profile_city_validation_uses_profile_country_not_job_country(self):
        city_field = Mock()
        city_field.count = AsyncMock(return_value=1)
        city_field.input_value = AsyncMock(return_value="Toronto")
        city_field.fill = AsyncMock()
        city_field.blur = AsyncMock()
        page = Mock()
        page.locator.return_value.first = city_field

        row = {
            "location": "Alpharetta, Georgia, United States",
            "profile": {
                "city": "Toronto",
                "state": "Ontario",
                "country": "Canada",
            },
        }
        with patch.object(
            flow, "validate_city_location", return_value=True
        ) as validate:
            await flow.validate_ceipal_city_before_save(page, row, "profile")

        validate.assert_called_once_with("Toronto, Ontario, Canada")
        city_field.fill.assert_not_awaited()

    async def test_ceipal_city_must_match_profile_json_city(self):
        city_field = Mock()
        city_field.count = AsyncMock(return_value=1)
        city_field.input_value = AsyncMock(side_effect=["Toronto", ""])
        city_field.fill = AsyncMock()
        city_field.blur = AsyncMock()
        page = Mock()
        page.locator.return_value.first = city_field
        row = {
            "profile": {
                "city": "Vancouver",
                "state": "British Columbia",
                "country": "Canada",
            },
        }

        with patch.object(flow, "validate_city_location") as validate:
            await flow.validate_ceipal_city_before_save(page, row, "profile")

        validate.assert_not_called()
        city_field.fill.assert_awaited_once_with("Vancouver")

    async def test_canada_job_uses_job_location_if_profile_country_is_not_canada(self):
        row = {
            "business_unit": "Canada",
            "location": "Toronto, Ontario, Canada",
            "profile": {
                "city": "New York",
                "state": "New York",
                "country": "United States",
            },
        }
        with patch.object(
            flow, "set_input_by_selectors", new=AsyncMock(return_value=True)
        ) as set_input, patch.object(
            flow, "detect_country_selector", new=AsyncMock(return_value=None)
        ):
            city_source = await flow.apply_job_location_before_save(Mock(), row)

        self.assertEqual(city_source, "job")
        self.assertEqual(
            [call.args[2] for call in set_input.await_args_list],
            ["Toronto", "Ontario"],
        )

    async def test_canada_job_requires_ceipal_country_to_be_canada(self):
        row = {
            "location": "Toronto, Ontario, Canada",
            "profile": {"country": "United States", "city": "Richmond"},
        }
        page = Mock()
        with patch.object(flow, "clean_job_location", return_value="Toronto, Ontario, Canada"), \
                patch.object(flow, "detect_country_selector", new=AsyncMock(return_value="#country")), \
                patch.object(flow, "read_selected_option_label", new=AsyncMock(return_value="Canada")), \
                patch.object(flow, "force_country_value", new=AsyncMock(return_value=True)) as force_country, \
                patch.object(flow, "fill_input_by_selectors", new=AsyncMock(return_value=True)) as fill_input, \
                patch("builtins.print") as log:
            await flow.enforce_canada_before_save(page, row)

        force_country.assert_awaited_once_with(page, "Canada")
        self.assertEqual(fill_input.await_args_list[0].args[2], "Toronto")
        self.assertTrue(any(
            "Canada patch: job city 'Toronto' verified True (7/18 characters)" in call.args[0]
            for call in log.call_args_list
        ))

    async def test_non_canada_job_country_is_not_overridden(self):
        row = {"location": "Seattle, Washington, United States"}
        with patch.object(
            flow,
            "clean_job_location",
            return_value="Seattle, Washington, United States",
        ), patch.object(
            flow,
            "detect_country_selector",
            new=AsyncMock(return_value="#country"),
        ) as detect_country:
            result = await flow.enforce_canada_before_save(Mock(), row)

        self.assertFalse(result)
        detect_country.assert_not_awaited()

    async def test_canada_job_does_not_continue_if_country_cannot_be_set(self):
        row = {"location": "Toronto, Ontario, Canada"}
        with patch.object(flow, "clean_job_location", return_value="Toronto, Ontario, Canada"), \
                patch.object(flow, "detect_country_selector", new=AsyncMock(return_value="#country")), \
                patch.object(flow, "read_selected_option_label", new=AsyncMock(return_value="United States")), \
                patch.object(flow, "force_country_value", new=AsyncMock(return_value=False)):
            with self.assertRaisesRegex(RuntimeError, "could not be set to Canada"):
                await flow.enforce_canada_before_save(Mock(), row)

    async def test_canada_business_unit_dc_state_sets_country_and_fills_verified_canadian_city(self):
        row = {
            "business_unit": "Canada",
            "location": "Washington, District of Columbia, United States",
            "profile": {
                "city": "Toronto",
                "state": "District of Columbia",
                "country": "Canada",
                "city_location_validated": True,
            },
        }
        page = Mock()
        with patch.object(flow, "clean_job_location", return_value=row["location"]), \
                patch.object(flow, "detect_country_selector", new=AsyncMock(return_value="#country")), \
                patch.object(flow, "read_selected_option_label", new=AsyncMock(return_value="Canada")), \
                patch.object(flow, "force_country_value", new=AsyncMock(return_value=True)) as force_country, \
                patch.object(flow, "fill_input_by_selectors", new=AsyncMock(return_value=True)) as fill_input:
            await flow.enforce_canada_before_save(page, row)

        force_country.assert_awaited_once_with(page, "Canada")
        fill_input.assert_awaited_once()
        self.assertEqual(fill_input.await_args.args[2], "Toronto")

    async def test_canada_business_unit_uses_profile_city_for_ai_check(self):
        row = {
            "business_unit": "Canada",
            "location": "Washington, District of Columbia, United States",
            "profile": {
                "city": "Toronto",
                "state": "District of Columbia",
                "country": "Canada",
                "city_location_validated": False,
            },
        }
        with patch.object(flow, "clean_job_location", return_value=row["location"]), \
                patch.object(flow, "detect_country_selector", new=AsyncMock(return_value="#country")), \
                patch.object(flow, "read_selected_option_label", new=AsyncMock(return_value="Canada")), \
                patch.object(flow, "force_country_value", new=AsyncMock(return_value=True)), \
                patch.object(flow, "fill_input_by_selectors", new=AsyncMock(return_value=True)) as fill_input:
            await flow.enforce_canada_before_save(Mock(), row)
            with patch.object(
                flow, "set_input_by_selectors", new=AsyncMock(return_value=True)
            ) as set_input, patch.object(
                flow, "detect_country_selector", new=AsyncMock(return_value=None)
            ):
                await flow.apply_job_location_before_save(Mock(), row)

        fill_input.assert_not_awaited()
        self.assertEqual(set_input.await_args_list[0].args[2], "Toronto")
        self.assertEqual(set_input.await_args_list[1].args[2], "")

    async def test_canada_dc_state_is_cleared_and_country_corrected_before_save(self):
        state_field = Mock()
        state_field.count = AsyncMock(return_value=1)
        state_field.evaluate = AsyncMock(
            side_effect=["District of Columbia", "INPUT", ""]
        )
        state_field.fill = AsyncMock()
        state_field.blur = AsyncMock()
        page = Mock()
        page.locator.return_value.first = state_field
        row = {
            "business_unit": "Canada",
            "profile": {"state": "District of Columbia"},
        }

        with patch.object(
            flow, "detect_country_selector", new=AsyncMock(return_value="#country")
        ), patch.object(
            flow,
            "read_selected_option_label",
            new=AsyncMock(side_effect=["United States", "Canada"]),
        ), patch.object(
            flow, "force_country_value", new=AsyncMock(return_value=True)
        ) as force_country, patch.object(flow, "CEIPAL_STATE_SELECTORS", ["#state"]):
            await flow.validate_canada_dc_profile_before_save(page, row)

        force_country.assert_awaited_once_with(page, "Canada")
        state_field.fill.assert_awaited_once_with("")
        state_field.blur.assert_awaited_once()

    async def test_dc_state_does_not_override_country_for_non_canada_business_unit(self):
        row = {
            "business_unit": "Commercial",
            "location": "Washington, District of Columbia, United States",
            "profile": {"state": "District of Columbia"},
        }
        with patch.object(
            flow,
            "detect_country_selector",
            new=AsyncMock(return_value="#country"),
        ) as detect_country:
            result = await flow.enforce_canada_before_save(Mock(), row)

        self.assertFalse(result)
        detect_country.assert_not_awaited()

    def test_public_url_is_preferred_over_the_talent_url(self):
        document = flow.render_resume_html(
            {"first_name": "A", "last_name": "B"},
            "https://www.linkedin.com/talent/profile/abc",
            "https://www.linkedin.com/in/a-b")
        self.assertIn("https://www.linkedin.com/in/a-b", document)
        self.assertNotIn("https://www.linkedin.com/talent/profile/abc", document)

    def test_resume_filename_is_safe_and_unique_per_profile(self):
        profile = {"first_name": "John", "last_name": "Mc Daniel"}
        self.assertEqual(
            flow.resume_filename(profile, "https://www.linkedin.com/talent/profile/abc"),
            "John-Mc-Daniel-abc.pdf")

    def test_resume_separates_each_employer_and_education_institution(self):
        profile = {
            "first_name": "Taylor",
            "last_name": "Example",
            "experience": [
                "Software Engineer\nAcme · Full-time\nJan 2020 – Present · 6 yrs 9 mos\n"
                "Remote\nBuilt reliable systems\nData Analyst\nBeta Corp · Full-time\n"
                "Jan 2018 – Dec 2019 · 2 yrs\nNew York\nImproved reporting"
            ],
            "education": [
                "North University\nBachelor of Science · Computer Science\n"
                "Sep 2014 – May 2018\nState College\nAssociate Degree\n"
                "Sep 2012 – May 2014"
            ],
        }
        document = flow.render_resume_html(profile, "https://example.test/profile")
        for expected in (
            "<h3 class='section-item-title'>Acme</h3>",
            "<h3 class='section-item-title'>Beta Corp</h3>",
            "<h3 class='section-item-title'>North University</h3>",
            "<h3 class='section-item-title'>State College</h3>",
            "Software Engineer",
            "Data Analyst",
            "Bachelor of Science",
            "Associate Degree",
        ):
            self.assertIn(expected, document)


class ProfileExpansionTests(unittest.IsolatedAsyncioTestCase):
    async def test_expands_new_show_more_buttons_until_all_content_is_loaded(self):
        class Button:
            def __init__(self, content, name):
                self.content = content
                self.name = name

            async def is_visible(self):
                return self.name in self.content.visible

            async def click(self):
                self.content.visible.remove(self.name)
                self.content.clicked.append(self.name)
                if self.name == "See more":
                    self.content.visible.append("Show more")

        class Buttons:
            def __init__(self, content):
                self.content = content

            async def all(self):
                return [Button(self.content, name) for name in self.content.visible]

        class Content:
            visible = ["See more"]
            clicked = []

            def get_by_role(self, role, name):
                self.assert_role = role
                return Buttons(self)

        content = Content()
        with patch.object(
            flow,
            "settled_text",
            AsyncMock(side_effect=["first expanded", "all expanded", "all expanded"]),
        ):
            text = await flow.expand_profile_content(object(), content)

        self.assertEqual(text, "all expanded")
        self.assertEqual(content.clicked, ["See more", "Show more"])


class TalentOnlyTests(unittest.TestCase):
    """Public /in/ profile pages must never be visited."""

    def test_only_talent_profile_urls_are_accepted(self):
        import recruit as api
        self.assertEqual(
            api.canonical_url("https://www.linkedin.com/talent/profile/abc?trk=x"),
            "https://www.linkedin.com/talent/profile/abc")
        self.assertIsNone(api.canonical_url("https://www.linkedin.com/in/someone"))
        self.assertIsNone(api.canonical_url("https://www.linkedin.com/in/someone/details/experience"))

    def test_location_search_variants_include_full_state_country_and_country(self):
        import recruit as api
        self.assertEqual(
            api.generate_location_variants("Richmond, Virginia, United States"),
            [
                "Richmond, Virginia, United States",
                "Virginia, United States",
                "United States",
            ],
        )


class LocationPassTests(unittest.IsolatedAsyncioTestCase):
    async def test_job_history_records_location_and_variants_before_search(self):
        location = "Toronto, Ontario, Canada"
        variants = [location, "Ontario, Canada", "Canada"]
        linkedin = SimpleNamespace(goto=AsyncMock())
        api = SimpleNamespace(
            SEARCH_URL="https://www.linkedin.com/talent/search",
            generate_location_variants=lambda value, business_unit: variants,
            apply_title=AsyncMock(),
            apply_location=AsyncMock(),
            wait_for_search_results=AsyncMock(),
            collect_profiles=AsyncMock(return_value=[]),
            save_state=Mock(),
        )
        job = {
            "code": "J-HISTORY",
            "url": "https://example.test/job",
            "title": "Engineer",
            "location": location,
            "location_variants": variants,
        }
        history = {}

        await flow.process_job(
            api,
            SimpleNamespace(limit=1, search_only=True, location=None),
            linkedin,
            None,
            None,
            job,
            {},
            history,
            Path("unused_history.json"),
            Mock(),
        )

        self.assertEqual(history["J-HISTORY"]["location"], location)
        self.assertEqual(history["J-HISTORY"]["location_search_variants"], variants)
        self.assertEqual(api.apply_location.await_args_list[0].args[1], location)

    async def test_missing_job_location_is_recorded_and_search_is_not_started(self):
        linkedin = SimpleNamespace(goto=AsyncMock())
        api = SimpleNamespace(
            SEARCH_URL="https://www.linkedin.com/talent/search",
            generate_location_variants=lambda value, business_unit: [],
            save_state=Mock(),
        )
        job = {
            "code": "J-NO-LOCATION",
            "url": "https://example.test/job",
            "title": "Engineer",
            "location": "",
            "location_variants": [],
        }
        history = {}

        with self.assertRaisesRegex(ValueError, "location is required"):
            await flow.process_job(
                api,
                SimpleNamespace(limit=1, search_only=True, location=None),
                linkedin,
                None,
                None,
                job,
                {},
                history,
                Path("unused_history.json"),
                Mock(),
            )

        self.assertEqual(history["J-NO-LOCATION"]["location"], "")
        self.assertEqual(history["J-NO-LOCATION"]["location_search_variants"], [])
        linkedin.goto.assert_not_awaited()

    async def test_each_location_finishes_profile_processing_before_next_search(self):
        urls = [
            "https://www.linkedin.com/talent/profile/city",
            "https://www.linkedin.com/talent/profile/state",
            "https://www.linkedin.com/talent/profile/country",
        ]
        variants = [
            "Richmond, Virginia, United States",
            "Virginia, United States",
            "United States",
        ]
        events = []
        linkedin = SimpleNamespace(goto=AsyncMock())
        api = SimpleNamespace(
            SEARCH_URL="https://www.linkedin.com/talent/search",
            generate_location_variants=lambda location, business_unit: variants,
            apply_title=AsyncMock(),
            apply_location=AsyncMock(side_effect=lambda page, location: events.append(("search", location))),
            wait_for_search_results=AsyncMock(),
            collect_profiles=AsyncMock(side_effect=[[url] for url in urls]),
            save_state=Mock(),
            ROOT=Path("."),
        )
        async def create(page, row, api, persist, code=None):
            events.append(("processed", row["url"]))
            row["status"] = "saved"

        job = {
            "code": "J-LOC", "url": "https://example.test/job",
            "title": "Engineer", "cleaned_title": "Engineer",
            "location": variants[0], "location_variants": variants,
        }
        args = SimpleNamespace(limit=1, search_only=False, location=None)
        history, profiles = {}, {}
        profile_page = SimpleNamespace(context=object())
        with patch.object(flow, "extract_profile", AsyncMock(return_value={"public_sections": ["Person"]})), \
                patch("url.build_skill_set", return_value={
                    "first_name": "Test", "last_name": "Person", "skills": [],
                }), \
                patch.object(flow, "write_resume_pdf", AsyncMock()), \
                patch.object(flow, "create_applicant", AsyncMock(side_effect=create)):
            await flow.process_job(
                api, args, linkedin, profile_page, None, job, profiles, history,
                Path("unused_history.json"), Mock(),
            )

        expected = []
        for variant, url in zip(variants, urls):
            expected.extend([("search", variant), ("processed", url)])
        self.assertEqual(events, expected)
        self.assertEqual(history["J-LOC"]["status"], "completed")
        self.assertEqual(history["J-LOC"]["location"], variants[0])
        self.assertEqual(history["J-LOC"]["location_search_variants"], variants)
        self.assertEqual(
            [item["location"] for item in history["J-LOC"]["location_searches"]],
            variants,
        )


if __name__ == "__main__":
    unittest.main()

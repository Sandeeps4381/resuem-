"""Cached job producer and LinkedIn-to-Ceipal manual applicant pipeline."""

import asyncio
import base64
import hashlib
import html
import json
import os
import re
import time
from datetime import date, datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit

import mysql.connector
from azure_title import clean_job_title, clean_job_location, validate_city_location
from profile_rules import is_valid_city_name, is_valid_state_name

FINAL = {
    "saved",
    "duplicate",
    "form_ready",
    "skipped_db_exists",
    "skipped_linkedin_member",
    "skipped_india_location",
    "skipped_resume_parser_failed",
}
UNCERTAIN = {"saving", "review_required"}

PUBLIC_PROFILE_RE = re.compile(
    r"https?://(?:[a-z0-9-]+\.)*linkedin\.com/in/[^\s?#]+", re.I
)

JOB_INDEX_PRIORITY = {
    "Federal": 1,
    "SLED": 2,
    "Canada": 3,
    "Healthcare": 4,
    "IT": 5,
    "Commercial": 6,
    "Non-IT": 7,
}

PARSE_RESUME_SELECTOR = "#parse_resume"
PARSE_TIMEOUT_S = 180
PROFILE_EXTRACTION_VERSION = 10


def is_applicant_snapshot(url):
    return bool(
        re.match(
            r"^/(?:applicant_profiles|applicantprofiles)/snapshot/[^/]+",
            urlsplit(url).path,
            re.I,
        )
    )


def read_store(path):
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return data


def json_safe(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    if isinstance(value, tuple):
        return [json_safe(v) for v in value]
    return value


def save_state_json(path, data):
    path.write_text(
        json.dumps(json_safe(data), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def db_connect():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST"),
        port=int(os.getenv("DB_PORT")),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME"),
    )


def build_title_mapping(titles):
    mapping = {}
    for title in titles or []:
        mapping[title] = clean_job_title(title)
    return mapping


def normalize_job_index(value):
    text = (value or "").strip().lower()
    mapping = {
        "federal": "Federal",
        "sled": "SLED",
        "canada": "Canada",
        "healthcare": "Healthcare",
        "it": "IT",
        "commercial": "Commercial",
        "non-it": "Non-IT",
        "non it": "Non-IT",
        "nonit": "Non-IT",
    }
    return mapping.get(text, "Commercial")


def job_sort_key(job):
    job_index = normalize_job_index(job.get("job_index") or job.get("business_unit"))
    return (
        JOB_INDEX_PRIORITY.get(job_index, 999),
        (job.get("code") or ""),
    )


def linkedin_public_url_exists(url, job_code=None):
    if not url:
        return False

    table = os.getenv("DB_PROFILE_URL")
    conn = db_connect()
    try:
        cur = conn.cursor()
        if job_code:
            cur.execute(
                f"SELECT id FROM {table} WHERE url=%s AND job_code=%s LIMIT 1",
                (url, job_code),
            )
        else:
            cur.execute(
                f"SELECT id FROM {table} WHERE url=%s LIMIT 1",
                (url,),
            )
        return cur.fetchone() is not None
    finally:
        conn.close()


def update_linkedin_havesting_status(
    url,
    job_code=None,
    business_unit=None,
    status=1,
    job_title=None,
    cleaned_job_title=None,
    date_posted=None,
):
    if not url:
        return

    table = os.getenv("DB_PROFILE_URL")
    conn = db_connect()
    try:
        cur = conn.cursor()

        if job_code:
            cur.execute(
                f"SELECT id FROM {table} WHERE url=%s AND job_code=%s LIMIT 1",
                (url, job_code),
            )
            existing = cur.fetchone()

            if existing:
                cur.execute(
                    f"UPDATE {table} SET status=%s, business_unit=%s, job_title=%s, cleaned_job_title=%s, date_posted=%s WHERE url=%s AND job_code=%s",
                    (
                        status,
                        business_unit,
                        job_title,
                        cleaned_job_title,
                        date_posted,
                        url,
                        job_code,
                    ),
                )
            else:
                cur.execute(
                    f"INSERT INTO {table} (url, job_code, business_unit, status, job_title, cleaned_job_title, date_posted) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    (
                        url,
                        job_code,
                        business_unit,
                        status,
                        job_title,
                        cleaned_job_title,
                        date_posted,
                    ),
                )
        else:
            cur.execute(f"SELECT id FROM {table} WHERE url=%s LIMIT 1", (url,))
            existing = cur.fetchone()

            if existing:
                cur.execute(
                    f"UPDATE {table} SET status=%s, job_title=%s, cleaned_job_title=%s, date_posted=%s WHERE url=%s",
                    (status, job_title, cleaned_job_title, date_posted, url),
                )
            else:
                cur.execute(
                    f"INSERT INTO {table} (url, status, job_title, cleaned_job_title, date_posted) VALUES (%s, %s, %s, %s, %s)",
                    (url, status, job_title, cleaned_job_title, date_posted),
                )

        conn.commit()
    finally:
        conn.close()


def update_job_processing_status(job_code, status=1):
    if not job_code:
        return

    table = os.getenv("DB_PROFILE_URL", "linkedin_havesting_url")
    conn = db_connect()
    try:
        cur = conn.cursor()
        cur.execute(f"UPDATE {table} SET job_status=%s WHERE job_code=%s", (status, job_code))
        conn.commit()
    finally:
        conn.close()


def is_linkedin_member_profile(profile):
    name = resume_name(profile).strip().casefold()
    return name == "linkedin member"


async def fill_if_empty(page, selector, value):
    field = page.locator(selector).first
    if not await field.count() or (await field.input_value()).strip():
        return False
    await field.fill(value)
    await field.blur()
    return True


async def choose_option(page, selector, label):
    field = page.locator(selector).first
    if not await field.count():
        return False
    try:
        await field.select_option(label=label)
        return True
    except Exception:
        pass
    return bool(
        await page.evaluate(
            """([selector, label]) => {
                const field = document.querySelector(selector);
                if (!field) return false;
                const wanted = label.trim().toLowerCase();
                const option = Array.from(field.options).find(o => o.text.trim().toLowerCase() === wanted);
                if (!option) return false;
                field.value = option.value;
                field.dispatchEvent(new Event('input', {bubbles: true}));
                field.dispatchEvent(new Event('change', {bubbles: true}));
                return true;
            }""",
            [selector, label],
        )
    )


async def safe_click(locator, timeout=10000):
    await locator.wait_for(state="visible", timeout=timeout)
    await locator.click(timeout=timeout)


async def detect_country_selector(page):
    selectors = [
        "#country",
        "select[name='country']",
        "select[name='country_id']",
        "select[name='Country']",
        "select[id*='country']",
        "select[name*='country']",
    ]
    for selector in selectors:
        locator = page.locator(selector).first
        try:
            if await locator.count():
                return selector
        except Exception:
            continue
    return None


def _normalized_location_token(value):
    return re.sub(r"[^a-z]", "", (value or "").strip().lower())


def _is_canada_location(value):
    token = _normalized_location_token(value)
    return token in {"canada", "ca"} or "canada" in token


def _is_district_of_columbia(value):
    token = _normalized_location_token(value)
    return token in {"districtofcolumbia", "dc"}


def _is_canada_business_unit(row):
    return any(
        _normalized_location_token(value) == "canada"
        for value in (row.get("business_unit"), row.get("job_index"))
        if value
    )


def _is_canada_dc_profile_job(row):
    profile = row.get("profile") or {}
    return _is_canada_business_unit(row) and _is_district_of_columbia(
        profile.get("state")
    )


def _verified_canadian_profile_city(profile):
    city = (profile.get("city") or "").strip()
    return (
        is_valid_city_name(city)
        and profile.get("city_location_validated") is True
        and _is_canada_location(profile.get("country"))
    )


CEIPAL_STATE_SELECTORS = [
    "#state",
    "#province",
    "select[name='state']",
    "select[name='State']",
    "select[name='province']",
    "select[name='Province']",
    "input[name='state']",
    "input[name='State']",
    "input[name='province']",
    "input[name='Province']",
    "select[id*='state']",
    "select[id*='province']",
    "input[id*='state']",
    "input[id*='province']",
    "input[placeholder*='State' i]",
    "input[aria-label*='State' i]",
]
CEIPAL_CITY_SELECTORS = [
    "#city",
    "input[name='city']",
    "input[name='City']",
    "input[id*='city']",
    "input[placeholder*='City' i]",
    "input[aria-label*='City' i]",
]


async def fill_input_by_selectors(page, selectors, value):
    if not value:
        return False
    for selector in selectors:
        try:
            if await fill_if_empty(page, selector, value):
                return True
        except Exception:
            continue
    return False


def _location_parts(value):
    if not value:
        return []
    return [part.strip() for part in str(value).split(",") if part and part.strip()]


def _extract_city_from_location(value):
    parts = _location_parts(value)
    return parts[0] if parts else ""


def _extract_province_from_location(value):
    parts = _location_parts(value)
    if len(parts) >= 2:
        return parts[1]
    return ""


JOB_LOCATION_COUNTRIES = {
    "canada", "united states", "united states of america", "usa", "us",
    "united kingdom", "uk", "australia", "india", "mexico",
}
JOB_LOCATION_REGIONS = {
    "alabama", "alaska", "arizona", "arkansas", "california", "colorado",
    "connecticut", "delaware", "florida", "georgia", "hawaii", "idaho",
    "illinois", "indiana", "iowa", "kansas", "kentucky", "louisiana",
    "maine", "maryland", "massachusetts", "michigan", "minnesota",
    "mississippi", "missouri", "montana", "nebraska", "nevada",
    "new hampshire", "new jersey", "new mexico", "new york",
    "north carolina", "north dakota", "ohio", "oklahoma", "oregon",
    "pennsylvania", "rhode island", "south carolina", "south dakota",
    "tennessee", "texas", "utah", "vermont", "virginia", "washington",
    "west virginia", "wisconsin", "wyoming", "district of columbia",
    "alberta", "british columbia", "manitoba", "new brunswick",
    "newfoundland and labrador", "northwest territories", "nova scotia",
    "nunavut", "ontario", "prince edward island", "quebec", "saskatchewan",
    "yukon",
}
INDIA_REGIONS = {
    "andaman and nicobar islands", "andhra pradesh", "arunachal pradesh",
    "assam", "bihar", "chandigarh", "chhattisgarh", "dadra and nagar haveli",
    "daman and diu", "delhi", "goa", "gujarat", "haryana", "himachal pradesh",
    "jammu and kashmir", "jharkhand", "karnataka", "kerala", "ladakh",
    "lakshadweep", "madhya pradesh", "maharashtra", "manipur", "meghalaya",
    "mizoram", "nagaland", "odisha", "puducherry", "punjab", "rajasthan",
    "sikkim", "tamil nadu", "telangana", "tripura", "uttar pradesh",
    "uttarakhand", "west bengal",
}


def _job_city_state(location):
    parts = _location_parts(location)
    if not parts:
        return "", ""

    if (
        len(parts) == 2
        and parts[1].casefold() in JOB_LOCATION_COUNTRIES
        and parts[0].casefold() in JOB_LOCATION_REGIONS
    ):
        return "", parts[0] if is_valid_state_name(parts[0]) else ""

    city = parts[0] if is_valid_city_name(parts[0]) else ""
    state = ""
    if len(parts) >= 3:
        state = parts[1] if is_valid_state_name(parts[1]) else ""
    elif len(parts) == 2 and parts[1].casefold() not in JOB_LOCATION_COUNTRIES:
        state = parts[1] if is_valid_state_name(parts[1]) else ""
    return city, state


def _job_location_parts(location):
    parts = _location_parts(location)
    city, state = _job_city_state(location)
    country = ""
    if len(parts) >= 3:
        country = parts[-1]
    elif len(parts) == 2 and parts[-1].casefold() in JOB_LOCATION_COUNTRIES:
        country = parts[-1]
        state = ""
    return city, state, country


def _ceipal_city(profile, job_city, canada_job=False):
    profile_city = (profile.get("city") or "").strip()
    profile_country = (profile.get("country") or "").strip()
    if (
        is_valid_city_name(profile_city)
        and (not canada_job or _is_canada_location(profile_country))
    ):
        return profile_city, "profile"
    if is_valid_city_name(job_city):
        return job_city, "job"
    return "", ""


async def set_input_by_selectors(page, selectors, value):
    for selector in selectors:
        field = page.locator(selector).first
        try:
            if not await field.count():
                continue
            tag_name = (await field.evaluate("el => el.tagName")).upper()
            if tag_name == "SELECT":
                if value and await choose_option(page, selector, value):
                    return True
                if not value:
                    try:
                        return bool(await field.evaluate(
                            """el => {
                                if (el.tagName !== 'SELECT') return false;
                                const option = Array.from(el.options).find(o => !o.value);
                                if (!option) return false;
                                el.value = option.value;
                                el.dispatchEvent(new Event('input', {bubbles: true}));
                                el.dispatchEvent(new Event('change', {bubbles: true}));
                                return true;
                            }"""
                        ))
                    except Exception:
                        continue
                continue
            await field.fill(value)
            await field.blur()
            return True
        except Exception:
            continue
    return False


async def apply_job_location_before_save(page, row):
    location = (row.get("location") or "").strip()
    job_city, job_state, job_country = _job_location_parts(location)
    profile = row.get("profile") or {}
    canada_dc_profile_job = _is_canada_dc_profile_job(row)
    canada_job = (
        _is_canada_business_unit(row)
        or _is_canada_location(job_country)
        or canada_dc_profile_job
    )
    city, city_source = _ceipal_city(profile, job_city, canada_job)
    if city_source == "profile":
        state = (profile.get("state") or "").strip()
        country = (profile.get("country") or "").strip()
    else:
        state = job_state
        country = job_country
        if canada_job:
            country = "Canada"
    if canada_dc_profile_job and _is_district_of_columbia(profile.get("state")):
        state = job_state if _is_canada_location(job_country) else ""
        print(
            "    Canada business unit: removing District of Columbia from state/province before save",
            flush=True,
        )
    city_applied = (
        await set_input_by_selectors(page, CEIPAL_CITY_SELECTORS, city)
        if city or canada_dc_profile_job else False
    )
    state_applied = (
        await set_input_by_selectors(page, CEIPAL_STATE_SELECTORS, state)
        if state or canada_dc_profile_job else False
    )
    country_applied = False
    if country:
        country_selector = await detect_country_selector(page)
        if country_selector:
            country_applied = await choose_option(page, country_selector, country)
            if not country_applied:
                print(
                    f"    Ceipal country option not found for {country!r}.",
                    flush=True,
                )
        else:
            print("    Ceipal country field was not found.", flush=True)
    city_valid = is_valid_city_name(city)
    print(
        f"    Ceipal city from {city_source or 'available locations'} verified: {city_valid} "
        f"({city!r}; {len(city)}/18 characters)",
        flush=True,
    )
    if city:
        print(f"    Ceipal city filled from {city_source}: {city}", flush=True)
    else:
        print(
            f"    Ceipal city cleared: no valid city was available "
            f"({location!r})",
            flush=True,
        )
    if location:
        if state:
            print(f"    Ceipal state set from job location: {state}", flush=True)
        elif canada_dc_profile_job:
            print(
                "    Ceipal state/province cleared for Canada business unit profile.",
                flush=True,
            )
        else:
            print("    Ceipal state cleared: no job state was present.", flush=True)
    if not city_applied:
        print("    Ceipal city field was not found or could not be updated.", flush=True)
    if state and not state_applied:
        print("    Ceipal state field was not found or could not be updated.", flush=True)
    if country and not country_applied:
        print("    Ceipal country could not be updated from the selected location.", flush=True)
    return city_source


async def validate_ceipal_city_before_save(page, row, city_source):
    if city_source != "profile":
        print("    Ceipal job city is not AI-validated.", flush=True)
        return

    city_field = None
    for selector in CEIPAL_CITY_SELECTORS:
        field = page.locator(selector).first
        if await field.count():
            city_field = field
            break

    if city_field is None:
        print("    Ceipal city validation skipped: city field was not found.", flush=True)
        return

    city = (await city_field.input_value()).strip()
    profile = row.get("profile") or {}
    profile_city = (profile.get("city") or "").strip()
    profile_state = (profile.get("state") or "").strip()
    profile_country = (profile.get("country") or "").strip()
    profile_location = ", ".join(
        part for part in (profile_city, profile_state, profile_country) if part
    )
    job_location = (row.get("location") or "").strip()

    same_as_profile_city = (
        bool(city)
        and bool(profile_city)
        and is_valid_city_name(profile_city)
        and " ".join(city.split()).casefold()
        == " ".join(profile_city.split()).casefold()
    )
    is_canada_job = (
        _is_canada_business_unit(row)
        or _is_canada_location(_job_location_parts(job_location)[2])
    )
    canada_profile_country_ok = (
        not is_canada_job or _is_canada_location(profile_country)
    )
    if (
        same_as_profile_city
        and profile_country
        and canada_profile_country_ok
        and validate_city_location(profile_location)
    ):
        print(
            f"    Ceipal profile city passed AI validation for "
            f"{profile_country}: {city}",
            flush=True,
        )
        return

    job_city, job_state, job_country = _job_location_parts(job_location)
    if (
        _is_canada_business_unit(row)
        or _is_canada_location(job_country)
    ):
        job_country = "Canada"
    await city_field.fill(job_city)
    await city_field.blur()
    if job_state:
        await set_input_by_selectors(page, CEIPAL_STATE_SELECTORS, job_state)
    if job_country:
        country_selector = await detect_country_selector(page)
        if country_selector:
            await choose_option(page, country_selector, job_country)
    print(
        f"    Ceipal profile city failed AI/country validation for "
        f"{profile_location!r}; using job location instead: {job_location!r}.",
        flush=True,
    )


async def validate_canada_dc_profile_before_save(page, row):
    if not _is_canada_dc_profile_job(row):
        return

    country_selector = await detect_country_selector(page)
    if not country_selector:
        raise RuntimeError(
            "Canada business-unit profile has a DC state, but the Ceipal country field was not found."
        )
    country = await read_selected_option_label(page, country_selector)
    if not _is_canada_location(country):
        if not await force_country_value(page, "Canada"):
            raise RuntimeError(
                f"Ceipal country must be Canada before saving this profile; "
                f"got '{country}' and could not change it."
            )
        country = await read_selected_option_label(page, country_selector)
        if not _is_canada_location(country):
            raise RuntimeError(
                f"Ceipal country must be Canada before saving this profile; "
                f"got '{country}' after correction."
            )

    state_found = False
    state_value = ""
    state_field = None
    state_selector = None
    for selector in CEIPAL_STATE_SELECTORS:
        field = page.locator(selector).first
        if not await field.count():
            continue
        state_found = True
        state_field = field
        state_selector = selector
        state_value = (
            await field.evaluate(
                """el => el.tagName === 'SELECT'
                    ? (el.options[el.selectedIndex]
                        ? (el.options[el.selectedIndex].text || '').trim()
                        : '')
                    : (el.value || '').trim()"""
            )
        )
        break

    if not state_found:
        print(
            "    Ceipal state/province field not found; no District of Columbia "
            "value can be submitted.",
            flush=True,
        )
        return

    if _is_district_of_columbia(state_value):
        if (await state_field.evaluate("el => el.tagName")).upper() == "SELECT":
            await set_input_by_selectors(page, [state_selector], "")
        else:
            await state_field.fill("")
            await state_field.blur()
        cleared_value = (
            await state_field.evaluate(
                """el => el.tagName === 'SELECT'
                    ? (el.options[el.selectedIndex]
                        ? (el.options[el.selectedIndex].text || '').trim()
                        : '')
                    : (el.value || '').trim()"""
            )
        )
        if _is_district_of_columbia(cleared_value):
            raise RuntimeError(
                "Could not remove District of Columbia from the Ceipal state field "
                "for a Canada profile."
            )
        print(
            "    Removed District of Columbia from Ceipal state before save; "
            "country is Canada.",
            flush=True,
        )


async def read_selected_option_label(page, selector):
    field = page.locator(selector).first
    if not await field.count():
        return ""
    try:
        return (
            await page.evaluate(
                """(selector) => {
                    const field = document.querySelector(selector);
                    if (!field) return '';
                    const option = field.options[field.selectedIndex];
                    return option ? (option.text || '').trim() : '';
                }""",
                selector,
            )
        ).strip()
    except Exception:
        return ""


async def force_country_value(page, wanted_country):
    country_selector = await detect_country_selector(page)
    if not country_selector:
        return False

    labels = [wanted_country]
    if wanted_country == "Canada":
        labels.extend(["CANADA", "CA"])
    elif wanted_country == "United States":
        labels.extend(["USA", "US"])

    for label in labels:
        if await choose_option(page, country_selector, label):
            await asyncio.sleep(0.5)
            selected_label = await read_selected_option_label(page, country_selector)
            if (
                _is_canada_location(selected_label)
                if wanted_country == "Canada"
                else _normalized_location_token(selected_label)
                == _normalized_location_token(wanted_country)
            ):
                return True
    return False


async def enforce_canada_before_save(page, row):
    job_location = clean_job_location((row.get("location") or "").strip()) if row.get("location") else ""
    canada_dc_profile_job = _is_canada_dc_profile_job(row)
    if not _is_canada_location(job_location) and not canada_dc_profile_job:
        return False

    country_selector = await detect_country_selector(page)
    if not country_selector:
        raise RuntimeError("Canada job detected, but the Ceipal country field was not found.")

    selected_before = await read_selected_option_label(page, country_selector)
    if _is_district_of_columbia(selected_before):
        print("    Canada patch: detected DC-like value in Canada case; forcing country to Canada", flush=True)

    if await force_country_value(page, "Canada"):
        print("    Canada patch: forced country to Canada", flush=True)
    else:
        raise RuntimeError("Canada job detected, but Ceipal country could not be set to Canada.")

    selected_after = await read_selected_option_label(page, country_selector)
    if not _is_canada_location(selected_after):
        print(f"    Canada patch: verification failed with selected country '{selected_after}', retrying Canada", flush=True)
        if not await force_country_value(page, "Canada"):
            raise RuntimeError("Ceipal country did not remain Canada after retry.")
        selected_after = await read_selected_option_label(page, country_selector)

    if not _is_canada_location(selected_after):
        print(f"    Canada patch: selected country still not Canada ('{selected_after}')", flush=True)
        raise RuntimeError(f"Ceipal country must be Canada for a Canada job; got '{selected_after}'.")

    print(f"    Canada patch: verified country as {selected_after}", flush=True)

    profile = row.get("profile") or {}
    job_city, canada_province, _ = _job_location_parts(job_location)
    if canada_dc_profile_job:
        canada_city = (
            (profile.get("city") or "").strip()
            if _verified_canadian_profile_city(profile)
            else ""
        )
        city_source = "verified Canadian profile" if canada_city else ""
        if not _is_canada_location(job_location):
            canada_province = ""
    else:
        canada_city, city_source = _ceipal_city(profile, job_city, canada_job=True)
    city_valid = is_valid_city_name(canada_city)
    print(
        f"    Canada patch: {city_source or 'available'} city {canada_city!r} "
        f"verified {city_valid} "
        f"({len(canada_city)}/18 characters)",
        flush=True,
    )
    applied = True

    if city_valid:
        city_filled = await fill_input_by_selectors(
            page,
            [
                "#city",
                "input[name='city']",
                "input[name='City']",
                "input[id*='city']",
                "input[placeholder*='City' i]",
                "input[aria-label*='City' i]",
            ],
            canada_city,
        )
        if city_filled:
            print(f"    Canada patch: filled city from {city_source}: {canada_city}", flush=True)
        else:
            print(f"    Canada patch: city fill skipped for {canada_city}", flush=True)

    if canada_province:
        province_filled = await fill_input_by_selectors(
            page,
            [
                "#state",
                "#province",
                "select[name='state']",
                "select[name='State']",
                "select[name='province']",
                "select[name='Province']",
                "input[name='state']",
                "input[name='State']",
                "input[name='province']",
                "input[name='Province']",
                "select[id*='state']",
                "select[id*='province']",
                "input[id*='state']",
                "input[id*='province']",
                "select[placeholder*='Province' i]",
                "select[aria-label*='Province' i]",
                "input[placeholder*='Province' i]",
                "input[aria-label*='Province' i]",
            ],
            canada_province,
        )
        if not province_filled:
            for selector in [
                "#state",
                "#province",
                "select[name='state']",
                "select[name='State']",
                "select[name='province']",
                "select[name='Province']",
                "select[id*='state']",
                "select[id*='province']",
            ]:
                try:
                    if await choose_option(page, selector, canada_province):
                        province_filled = True
                        break
                except Exception:
                    continue
        if province_filled:
            print(f"    Canada patch: filled province/state {canada_province}", flush=True)
        else:
            print(f"    Canada patch: province/state fill skipped for {canada_province}", flush=True)

    return applied


async def apply_dc_location_patch(page, row):
    profile = row.get("profile") or {}
    job_location = clean_job_location((row.get("location") or "").strip()) if row.get("location") else ""
    job_location_city = ""
    if job_location:
        job_location_city = job_location.split(",", 1)[0].strip()

    state = (profile.get("state") or "").strip()
    country = (profile.get("country") or "").strip()
    business_unit = (row.get("business_unit") or row.get("job_index") or "").strip()

    if any(
        _is_canada_location(value)
        for value in [country, job_location, business_unit]
        if value
    ):
        return False

    if not _is_district_of_columbia(state):
        return False

    applied = False
    if await force_country_value(page, "United States"):
        print("    District of Columbia patch: forced country to United States", flush=True)
        applied = True

    if job_location_city:
        city_filled = await fill_input_by_selectors(
            page,
            [
                "#city",
                "input[name='city']",
                "input[name='City']",
                "input[id*='city']",
                "input[placeholder*='City' i]",
                "input[aria-label*='City' i]",
            ],
            job_location_city,
        )
        if city_filled:
            print(f"    District of Columbia patch: filled city {job_location_city}", flush=True)
            applied = True

    return applied


async def click_submit_then_open_quick_tag(page):
    submit_candidates = [
        page.locator("//li[@id='restrict_status_div']//a[contains(text(),'Submit')]").first,
        page.locator("li#restrict_status_div a.dropdown-toggle").first,
        page.locator("a.dropdown-toggle:has-text('Submit')").first,
        page.get_by_role("link", name=re.compile(r"submit", re.I)).first,
    ]

    submit_clicked = False
    for locator in submit_candidates:
        try:
            if await locator.count():
                await locator.scroll_into_view_if_needed()
                await locator.click(force=True)
                await asyncio.sleep(1)
                submit_clicked = True
                break
        except Exception:
            continue

    if not submit_clicked:
        print("    quick tag skipped; Submit button not found", flush=True)
        return False

    quick_tag_candidates = [
        page.locator("//a[contains(@class,'tag_to_job_cls')]").first,
        page.locator("a.tag_to_job_cls").first,
        page.get_by_role("link", name=re.compile(r"quick tag", re.I)).first,
    ]

    for locator in quick_tag_candidates:
        try:
            if await locator.count():
                await locator.scroll_into_view_if_needed()
                await locator.click(force=True)
                await asyncio.sleep(5)
                print("    Quick Tag opened", flush=True)
                return True
        except Exception:
            continue

    print("    Quick Tag open failed", flush=True)
    return False


async def select_job_code_in_quick_tag(page, job_code):
    if not job_code:
        print("    No job_code Ã¢â€ â€™ skipping", flush=True)
        return False

    try:
        print("    Starting FINAL FIX...", flush=True)

        dropdown = page.locator('//*[@id="JobSeekerAppliedJobViewListForm"]/div[2]/div[1]').first
        await dropdown.wait_for(state="visible", timeout=15000)
        await dropdown.scroll_into_view_if_needed()
        await dropdown.click(force=True)
        print("    REAL CLICK DONE", flush=True)

        await asyncio.sleep(2)

        search_input = page.locator('//*[@id="select2-drop"]/div/input').first
        await search_input.wait_for(state="visible", timeout=15000)
        print("    Dropdown is visible now", flush=True)

        await search_input.fill("")
        await search_input.fill(job_code)
        print(f"    Typed: {job_code}", flush=True)

        await asyncio.sleep(2)

        result = page.locator("//li[contains(@class,'select2-result-selectable')]").first
        await result.wait_for(state="visible", timeout=15000)
        await result.click()
        print("    Job selected", flush=True)
        return True

    except Exception as e:
        print(f"    Job search failed: {e}", flush=True)
        return False


async def save_quick_tag(page):
    try:
        save_tag_btn = page.locator("//button[contains(@class,'save_tag_to_job')]").first
        await save_tag_btn.wait_for(state="visible", timeout=15000)
        await save_tag_btn.click(force=True)
        print("    Tag saved", flush=True)
        await asyncio.sleep(2)
        return True
    except Exception as e:
        print(f"    Tag save failed: {e}", flush=True)
        return False


async def quick_tag_job(page, job_code):
    if not job_code:
        return False

    try:
        opened = await click_submit_then_open_quick_tag(page)
        if not opened:
            return False

        selected = await select_job_code_in_quick_tag(page, job_code)
        if not selected:
            return False

        saved = await save_quick_tag(page)
        return saved

    except Exception as exc:
        print(f"    quick tag failed for job code {job_code}: {exc}", flush=True)
        return False


async def create_applicant(page, row, api, persist, job_code=None):
    path = Path(row.get("resume_path", ""))
    if not path.is_file():
        raise ValueError(
            f"Resume {path} is missing; clear this profile's 'profile' entry to rebuild it."
        )

    db_url = row.get("raw", {}).get("public_url") or row.get("public_url") or row["url"]

    if linkedin_public_url_exists(db_url, job_code):
        row["status"] = "skipped_db_exists"
        row["skip_reason"] = "public_url already exists in DB"
        row["public_url"] = db_url
        persist()
        print(f"    skipped Ceipal upload; public URL already exists in DB: {db_url}", flush=True)
        return

    def cleanup_resume_file():
        try:
            if path.is_file():
                path.unlink()
                row["resume_deleted"] = True
                row["resume_path"] = ""
                persist()
                print(f"    deleted local resume after Ceipal upload failure/skip: {path}", flush=True)
        except Exception as exc:
            print(f"    failed to delete local resume {path}: {exc}", flush=True)

    try:
        await page.goto(
            os.getenv("CEIPAL_ADD_APPLICANT_URL", api.existing.CEIPAL_ADD_APPLICANT_URL),
            wait_until="domcontentloaded",
            timeout=180000,
        )

        upload = page.locator(os.getenv("CEIPAL_PARSE_RESUME_SELECTOR", PARSE_RESUME_SELECTOR)).first
        await upload.wait_for(state="attached", timeout=60000)
        await upload.set_input_files(str(path))

        confirm = page.locator(api.existing.CEIPAL_CONFIRM_SELECTOR).first
        await confirm.wait_for(state="visible", timeout=60000)
        await confirm.click()

        parsed = page.locator(api.existing.CEIPAL_PARSED_FORM_SELECTOR)
        duplicate = page.locator(api.existing.CEIPAL_DUPLICATE_MODAL_SELECTOR)
        deadline = time.time() + PARSE_TIMEOUT_S

        while time.time() < deadline:
            if await duplicate.count() and await duplicate.is_visible():
                row["status"] = "duplicate"
                row["public_url"] = db_url
                persist()
                cleanup_resume_file()
                if job_code:
                    update_linkedin_havesting_status(
                        db_url,
                        job_code,
                        row.get("business_unit"),
                        1,
                        job_title=row.get("job_title"),
                        cleaned_job_title=row.get("cleaned_job_title"),
                        date_posted=row.get("date_posted") or datetime.now(),
                    )
                    update_job_processing_status(job_code, 1)
                print("    Ceipal already knows this applicant.", flush=True)
                return

            if await parsed.count():
                break

            await asyncio.sleep(1)
        else:
            raise TimeoutError("Ceipal did not return the parsed applicant form")

        if "dummy_email" not in row:
            row["dummy_email"] = api.existing.dummy_email(
                hashlib.sha256(row["url"].encode()).hexdigest()[:16]
            )
            row["dummy_mobile"] = api.existing.dummy_mobile()
            persist()

        if await fill_if_empty(page, api.existing.CEIPAL_EMAIL_SELECTOR, row["dummy_email"]):
            print(f"    filled placeholder email {row['dummy_email']}", flush=True)

        if await fill_if_empty(page, api.existing.CEIPAL_MOBILE_SELECTOR, row["dummy_mobile"]):
            print("    filled placeholder mobile number", flush=True)

        source = os.getenv("CEIPAL_SOURCE", api.existing.CEIPAL_DEFAULT_SOURCE)
        if await choose_option(page, api.existing.CEIPAL_SOURCE_SELECTOR, source):
            print(f"    set source to {source}", flush=True)

        await enforce_canada_before_save(page, row)
        await apply_dc_location_patch(page, row)
        city_source = await apply_job_location_before_save(page, row)
        await validate_ceipal_city_before_save(page, row, city_source)
        await validate_canada_dc_profile_before_save(page, row)

        save = page.locator(
            os.getenv("CEIPAL_PARSE_SAVE_SELECTOR", api.existing.CEIPAL_SAVE_SELECTOR + ":visible")
        ).first
        await save.wait_for(state="visible", timeout=60000)

        row["status"] = "saving"
        persist()
        await save.click()

        for _ in range(60):
            if is_applicant_snapshot(page.url):
                row["status"] = "saved"
                row["applicant_url"] = page.url
                row["public_url"] = db_url
                persist()

                if job_code:
                    update_linkedin_havesting_status(
                        db_url,
                        job_code,
                        row.get("business_unit"),
                        1,
                        job_title=row.get("job_title"),
                        cleaned_job_title=row.get("cleaned_job_title"),
                        date_posted=row.get("date_posted") or datetime.now(),
                    )
                    update_job_processing_status(job_code, 1)

                try:
                    tagged = await quick_tag_job(page, job_code)
                    row["tag_job_status"] = "tagged" if tagged else "tag_failed_or_skipped"
                    persist()
                except Exception as exc:
                    row["tag_job_status"] = f"tag_error: {exc}"
                    persist()
                    print(f"    tag job failed but continuing: {exc}", flush=True)

                cleanup_resume_file()
                return

            duplicate_modal = page.locator(api.existing.CEIPAL_DUPLICATE_MODAL_SELECTOR).first
            if await duplicate_modal.count() and await duplicate_modal.is_visible():
                row["status"] = "duplicate"
                row["public_url"] = db_url
                persist()
                cleanup_resume_file()
                if job_code:
                    update_linkedin_havesting_status(
                        db_url,
                        job_code,
                        row.get("business_unit"),
                        1,
                        job_title=row.get("job_title"),
                        cleaned_job_title=row.get("cleaned_job_title"),
                        date_posted=row.get("date_posted") or datetime.now(),
                    )
                    update_job_processing_status(job_code, 1)
                return

            await asyncio.sleep(1)

        raise RuntimeError("Ceipal save not confirmed; reconcile this applicant before retrying.")

    except Exception as exc:
        print(f"    resume parse/upload failed for {db_url}: {exc}", flush=True)
        row["status"] = "skipped_resume_parser_failed"
        row["skip_reason"] = "resume_parser_failed_skipped"
        row["public_url"] = db_url
        persist()
        cleanup_resume_file()

        if job_code:
            update_linkedin_havesting_status(
                db_url,
                job_code,
                row.get("business_unit"),
                1,
                job_title=row.get("job_title"),
                cleaned_job_title=row.get("cleaned_job_title"),
                date_posted=row.get("date_posted") or datetime.now(),
            )
            update_job_processing_status(job_code, 1)

        print("    parser failed, candidate skipped, resume deleted, marked completed.", flush=True)
        return


def find_public_profile_url(text, name):
    candidates = []
    for match in PUBLIC_PROFILE_RE.finditer(text or ""):
        segments = [segment for segment in urlsplit(match.group(0)).path.split("/") if segment]
        if len(segments) != 2 or segments[0] != "in":
            continue
        url = f"https://www.linkedin.com/in/{segments[1]}"
        if url not in candidates:
            candidates.append(url)
    if not candidates:
        return ""

    words = re.findall(r"[A-Za-z]{3,}", name or "")
    tokens = {words[0].casefold(), words[-1].casefold()} if words else set()
    for url in candidates:
        slug = urlsplit(url).path.rstrip("/").rsplit("/", 1)[-1].casefold()
        if tokens and all(token in slug for token in tokens):
            return url
    return candidates[0]


async def settled_text(content, quiet_rounds=3, max_rounds=24):
    text = ""
    previous = -1
    stable = 0
    for _ in range(max_rounds):
        text = (await content.inner_text()).strip()
        if text and len(text) == previous:
            stable += 1
            if stable >= quiet_rounds:
                break
        else:
            stable = 0
            previous = len(text)
        await asyncio.sleep(0.5)
    return text


async def expand_profile_content(page, content):
    """Click each existing profile disclosure once, then return the expanded text."""
    await page.evaluate("""async () => {
      const step = Math.max(400, Math.floor(window.innerHeight * 0.8));
      for (let y = 0; y < document.body.scrollHeight; y += step) {
        window.scrollTo(0, y);
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      window.scrollTo(0, document.body.scrollHeight);
    }""")
    await page.wait_for_timeout(750)
    await page.evaluate("() => window.scrollTo(0, 0)")
    await page.wait_for_timeout(500)

    disclosures = content.locator(
        "button[data-live-test-expandable-button], "
        "button[data-test-expand-more-lower-button], "
        "button[data-test-expand-more-upper-button], "
        "button[id*='expand-more'], "
        "button[aria-label*='show all' i], "
        "button[aria-label*='show more' i], "
        "button[aria-label*='see more' i], "
        "button:has-text('Show all'), "
        "button:has-text('Show more'), "
        "button:has-text('See more'), "
        "a[aria-label*='show all' i], "
        "a[aria-label*='show more' i], "
        "a[aria-label*='see more' i], "
        "a:has-text('Show all'), "
        "a:has-text('Show more'), "
        "a:has-text('See more')"
    )
    for disclosure in await disclosures.all():
        if await disclosure.is_visible() and await disclosure.get_attribute("aria-expanded") != "true":
            await disclosure.scroll_into_view_if_needed()
            await disclosure.click()
            await page.wait_for_timeout(150)

    return (await content.inner_text()).strip()


async def expand_certification_disclosures(page, content):
    """Keep expanding disclosures inside Certifications until that section is complete."""
    sections = content.locator('[data-section="certifications"]')
    section = sections.first

    if not await sections.count():
        headings = content.locator("h1, h2, h3, h4, [role='heading']")
        for heading in await headings.all():
            label = (await heading.inner_text()).strip().casefold()
            if label not in {"licenses & certifications", "certifications"}:
                continue
            section = heading.locator(
                "xpath=ancestor::section[1]"
            )
            if await section.count():
                break
            section = heading.locator(
                "xpath=ancestor::*[.//button[@data-live-test-expandable-button] "
                "or .//button[contains(@class, 'expandable-list__button')]][1]"
            )
            if await section.count():
                break
        else:
            return

    disclosure_selector = (
        "button[data-live-test-expandable-button], "
        "button[data-test-expand-more-lower-button], "
        "button[data-test-expand-more-upper-button], "
        "button[id*='expand-more'], "
        "button[aria-label*='show all' i], "
        "button[aria-label*='show more' i], "
        "button[aria-label*='see more' i], "
        "button:has-text('Show all'), "
        "button:has-text('Show more'), "
        "button:has-text('See more'), "
        "a[aria-label*='show all' i], "
        "a[aria-label*='show more' i], "
        "a[aria-label*='see more' i], "
        "a:has-text('Show all'), "
        "a:has-text('Show more'), "
        "a:has-text('See more')"
    )

    for _ in range(100):
        buttons = section.locator(disclosure_selector)
        next_button = None
        for button in await buttons.all():
            if (
                await button.is_visible()
                and await button.get_attribute("aria-expanded") != "true"
            ):
                next_button = button
                break
        if next_button is None:
            return
        await next_button.scroll_into_view_if_needed()
        await next_button.click()
        await page.wait_for_timeout(250)

    raise RuntimeError(
        "Certification disclosures are still available after expanding 100 controls."
    )


async def read_profile_text(page, url):
    await page.goto(url, wait_until="domcontentloaded", timeout=90000)
    if any(marker in page.url for marker in ("/login", "/authwall", "/checkpoint")):
        raise RuntimeError("LinkedIn profile requires login/verification.")
    override = os.getenv("LINKEDIN_PROFILE_CONTENT_SELECTOR")
    content = page.locator(override or 'main, [role="main"]').first
    await content.wait_for(state="visible", timeout=30000)
    text = await expand_profile_content(page, content)
    await expand_certification_disclosures(page, content)
    text = (await content.inner_text()).strip()
    if len(text) < 50:
        raise ValueError("No usable profile content found.")
    return text


async def extract_profile(page, url):
    text = await read_profile_text(page, url)
    listed_skills = []
    for selector in (
        'section[data-section="skills"] li h3',
        'section[data-section="skills"] .skill__name',
        '[data-section="skills"] li h3',
        '[data-section="skills"] .skill__name',
    ):
        for item in await page.locator(selector).all():
            if await item.is_visible():
                skill = (await item.inner_text()).strip()
                if skill and skill.casefold() not in {
                    value["skill"].casefold() for value in listed_skills
                }:
                    listed_skills.append({"skill": skill, "evidence": skill})

    raw = {
        "url": url,
        "public_sections": [text],
        "skill_mentions": listed_skills,
    }
    name = text.splitlines()[0].strip()
    public_url = find_public_profile_url(text, name)
    if public_url:
        raw["public_url"] = public_url
    return raw


RESUME_CSS = """
  @page { size: A4; margin: 14mm 13mm; }
  * { box-sizing: border-box; }
  body { font-family: "Segoe UI", Calibri, Arial, sans-serif; color: #1f2328;
         font-size: 10.5pt; line-height: 1.45; margin: 0; }
  header { border-bottom: 2px solid #1f2328; padding-bottom: 8px; margin-bottom: 14px; }
  h1 { font-size: 21pt; margin: 0 0 4px; letter-spacing: 0.3px; }
  .headline { font-size: 11.5pt; color: #444d56; margin-bottom: 5px; }
  .meta { font-size: 9.5pt; color: #57606a; }
  .meta span + span::before { content: "  |  "; color: #b0b7bf; }
  h2 { font-size: 11pt; text-transform: uppercase; letter-spacing: 0.9px;
       border-bottom: 1px solid #d0d7de; padding-bottom: 3px;
       margin: 14px 0 7px; color: #1f2328;
       break-after: avoid; page-break-after: avoid; }
  .section-item-title { font-size: 10.5pt; margin: 4px 0 2px; break-after: avoid; }
  .entry { margin-bottom: 6px; break-inside: avoid; white-space: pre-line; }
  .experience-entry { break-inside: auto; page-break-inside: auto; }
  .raw-entry { white-space: pre-line; }
  .role-title { font-size: 11pt; font-weight: 700; line-height: 1.3;
                margin: 0 0 2px; break-after: avoid; page-break-after: avoid; }
  .role-company, .role-dates { color: #444d56; font-size: 10pt; }
  .role-dates { margin-bottom: 4px; }
  .sub { color: #444d56; font-size: 10pt; }
  .description { white-space: pre-line; }
  .description ul { margin: 3px 0 5px; padding-left: 18px; }
  .description li { margin: 0 0 3px; }
  .chip { display: inline-block; border: 1px solid #d0d7de; border-radius: 3px;
          padding: 1px 7px; margin: 0 5px 5px 0; font-size: 9.5pt; }
"""


def escape(value):
    return html.escape(value or "", quote=True)


def resume_name(profile):
    return " ".join(
        part.strip()
        for part in (profile.get("first_name"), profile.get("last_name"))
        if part and part.strip()
    )


def resume_filename(profile, url):
    name = re.sub(r"[^A-Za-z0-9._-]+", "-", resume_name(profile)).strip("-") or "profile"
    source = re.sub(r"[^A-Za-z0-9._-]+", "-", urlsplit(url).path.rstrip("/").rsplit("/", 1)[-1])
    return f"{name}-{source or 'profile'}.pdf"


def extract_location_from_raw_profile(raw):
    sections = raw.get("public_sections", []) if isinstance(raw, dict) else []
    if not isinstance(sections, list):
        return {}

    lines = [line.strip() for section in sections if isinstance(section, str)
             for line in section.splitlines() if line.strip()]
    if not lines:
        return {}

    header = []
    for line in lines:
        if re.match(r"^(about|experience|education|skills|licenses & certifications|projects|contact info)\b", line, re.I):
            break
        header.append(line)

    for line in header:
        for segment in re.split(r"\s*[Â·â€¢]\s*", line):
            location = segment.split("Contact Info")[0].strip(" ,|-")
            if not location or any(ch.isdigit() for ch in location):
                continue
            fields = [part.strip() for part in location.split(",") if part.strip()]
            if len(fields) >= 2 and len(fields) <= 3:
                city = fields[0]
                state = fields[1] if len(fields) >= 2 else ""
                country = fields[2] if len(fields) >= 3 else ""
                if city and state:
                    return {
                        "city": city,
                        "state": state,
                        "country": country,
                        "full_location": ", ".join(part for part in (city, state, country) if part),
                    }
    return {}


def is_currently_in_india(profile, raw):
    profile = profile if isinstance(profile, dict) else {}
    raw_location = extract_location_from_raw_profile(raw)
    india_tokens = [
        raw_location.get("full_location", ""),
        raw_location.get("country", ""),
        raw_location.get("state", ""),
        profile.get("location", ""),
        profile.get("country", ""),
    ]
    if any(
        _normalized_location_token(part) == "india"
        or _normalized_location_token(part).endswith("india")
        for location in india_tokens
        for part in str(location or "").split(",")
    ):
        return True

    countries = [
        raw_location.get("country", ""),
        profile.get("country", ""),
    ]
    if any(str(country or "").strip() for country in countries):
        return False

    return any(
        _normalized_location_token(region) in INDIA_REGIONS
        for region in (raw_location.get("state", ""), profile.get("state", ""))
    )


def ensure_profile_location(profile, raw):
    profile = profile if isinstance(profile, dict) else {}
    raw_location = extract_location_from_raw_profile(raw)
    changed = False

    if raw_location.get("city") and not (profile.get("city") or "").strip():
        profile["city"] = raw_location["city"]
        changed = True
    if raw_location.get("state") and not (profile.get("state") or "").strip():
        profile["state"] = raw_location["state"]
        changed = True
    if raw_location.get("country") and not (profile.get("country") or "").strip():
        profile["country"] = raw_location["country"]
        changed = True

    location_parts = [part.strip() for part in (
        profile.get("city"),
        profile.get("state"),
        profile.get("country"),
    ) if part and part.strip()]
    if location_parts:
        computed = ", ".join(location_parts)
        if (profile.get("location") or "").strip() != computed:
            profile["location"] = computed
            changed = True
    elif raw_location.get("full_location") and not (profile.get("location") or "").strip():
        profile["location"] = raw_location["full_location"]
        changed = True

    return changed

def resume_block(block):
    if isinstance(block, dict):
        parts = []

        title = clean_resume_text(
            block.get("title") or block.get("school") or block.get("name")
        )
        organization = clean_resume_text(
            block.get("issuer") or block.get("company") or block.get("degree")
        )
        duration = clean_resume_text(
            block.get("duration") or block.get("dates") or block.get("issued")
        )
        location = clean_resume_text(block.get("location"))
        description = clean_resume_text(
            block.get("description") or block.get("details") or block.get("extra")
        )

        if title:
            parts.append(f"<div><strong>{escape(title)}</strong></div>")

        sub_items = [item for item in (organization, duration, location) if item]
        if sub_items:
            parts.append(f"<div class='sub'>{escape(' | '.join(sub_items))}</div>")

        if description:
            parts.append(f"<div class='description'>{escape(description)}</div>")
        if block.get("score"):
            parts.append(
                f"<div class='sub'>{escape(clean_resume_text(block['score']))}</div>"
            )
        if block.get("credential_id"):
            credential_id = clean_resume_text(block["credential_id"])
            if credential_id:
                parts.append(f"<div class='sub'>Credential ID: {escape(credential_id)}</div>")
        if block.get("credential_url"):
            credential_url = clean_resume_text(block["credential_url"])
            if credential_url:
                parts.append(f"<div class='sub'>Credential: {escape(credential_url)}</div>")

        return f"<div class='entry'>{''.join(parts)}</div>"

    return f"<div class='entry raw-entry'>{escape(clean_resume_text(block))}</div>"


def resume_certification_block(block):
    if not isinstance(block, dict):
        return resume_block(block)

    title = clean_resume_text(block.get("name") or block.get("title") or "")
    issuer = clean_resume_text(block.get("issuer") or "")
    issued = clean_resume_text(block.get("issued") or "")
    issuer = re.sub(r"^(?:issued by|issuing organization)\s*:\s*", "", issuer, flags=re.I)
    issued = re.sub(r"^issued(?:\s+date)?\s*:?\s*", "", issued, flags=re.I)
    if re.fullmatch(
        r"(?:[A-Za-z]{3,9}\s+)?\d{4}\s*[-\u2013\u2014]\s*"
        r"(?:Present|(?:[A-Za-z]{3,9}\s+)?\d{4})",
        title,
        re.I,
    ):
        issued = issued or title
        title = ""
    credential_id = clean_resume_text(block.get("credential_id") or "")
    credential_url = clean_resume_text(block.get("credential_url") or "")
    description = clean_resume_text(
        block.get("description") or block.get("details") or block.get("extra")
    )

    parts = ["<div class='entry'>"]
    if issuer:
        parts.append(f"<div class='sub'>{escape(issuer)}</div>")
    if title:
        parts.append(f"<div><strong>{escape(title)}</strong></div>")
    if issued:
        parts.append(f"<div class='sub'>{escape(issued)}</div>")
    if description:
        parts.append(f"<div class='description'>{escape(description)}</div>")
    if credential_id:
        parts.append(f"<div class='sub'>Credential ID: {escape(credential_id)}</div>")
    if credential_url:
        parts.append(f"<div class='sub'>Credential: {escape(credential_url)}</div>")
    parts.append("</div>")
    return "".join(parts)


RESUME_UI_NOISE_RE = re.compile(
    r"\b(?:see more|see less|show more|show less|show all(?:\s+\d+)?)\b",
    re.I,
)


def clean_resume_text(value):
    if not value:
        return ""
    cleaned_lines = []
    for line in str(value).splitlines():
        if re.fullmatch(r"\s*(?:more|less)\s*", line, re.I):
            continue
        cleaned = RESUME_UI_NOISE_RE.sub("", line)
        cleaned = re.sub(r"\s{2,}", " ", cleaned).strip(" \t\u00b7-|")
        if cleaned:
            cleaned_lines.append(cleaned)
    return "\n".join(cleaned_lines)


def resume_experience_block(block):
    title = clean_resume_text(block.get("title") or block.get("role") or "")
    company = clean_resume_text(block.get("company") or "")
    duration = clean_resume_text(block.get("duration") or block.get("dates") or "")
    location = clean_resume_text(block.get("location") or "")
    description = clean_resume_text(block.get("description") or block.get("details") or "")

    parts = ["<div class='entry experience-entry'>"]
    if title:
        parts.append(f"<h4 class='role-title'>{escape(title)}</h4>")
    if company:
        parts.append(f"<div class='role-company'>{escape(company)}</div>")
    date_meta = [value for value in (duration, location) if value]
    if date_meta:
        parts.append(f"<div class='role-dates'>{escape(' | '.join(date_meta))}</div>")
    if description:
        parts.append(f"<div class='description'>{escape(description)}</div>")
    parts.append("</div>")
    return "".join(parts)


RESUME_DATE_RE = re.compile(
    r"^(?:[A-Z][a-z]{2}\s+)?\d{4}\s*[-\u2013\u2014]\s*"
    r"(?:Present|(?:[A-Z][a-z]{2}\s+)?\d{4})",
    re.I,
)
RESUME_EMPLOYMENT_TYPES = (
    "Full-time|Part-time|Self-employed|Freelance|Contract|Internship|"
    "Apprenticeship|Seasonal"
)
RESUME_COMPANY_TYPE_RE = re.compile(
    rf"^(?P<company>.+?)\s*\u00b7\s*(?:{RESUME_EMPLOYMENT_TYPES})$",
    re.I,
)
RESUME_COMPANY_DURATION_RE = re.compile(
    rf"^(?:{RESUME_EMPLOYMENT_TYPES})\s*\u00b7\s*\d+\s*(?:yr|mo)",
    re.I,
)


def _profile_section_text(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "\n".join(
            item if isinstance(item, str) else ""
            for item in value
        )
    return ""


def _parse_resume_experience(value):
    lines = [line.strip() for line in _profile_section_text(value).splitlines() if line.strip()]
    anchors = [
        index for index, line in enumerate(lines)
        if RESUME_DATE_RE.match(line)
    ]
    entries = []
    company_at = {}
    for index, line in enumerate(lines):
        match = RESUME_COMPANY_TYPE_RE.match(line)
        if match:
            company_at[index] = match.group("company")
        elif index > 0 and RESUME_COMPANY_DURATION_RE.match(line):
            company_at[index - 1] = lines[index - 1]

    for position, date_index in enumerate(anchors):
        company_match = (
            RESUME_COMPANY_TYPE_RE.match(lines[date_index - 1])
            if date_index > 0 else None
        )
        if company_match:
            title = lines[date_index - 2] if date_index >= 2 else ""
            company = company_match.group("company")
        else:
            title = lines[date_index - 1] if date_index > 0 else ""
            company = next(
                (
                    company_at[index]
                    for index in sorted(company_at, reverse=True)
                    if index < date_index - 1
                ),
                "",
            )

        if not title:
            continue
        next_date = anchors[position + 1] if position + 1 < len(anchors) else len(lines)
        details_start = date_index + 1
        details_end = next_date
        if next_date < len(lines):
            if RESUME_COMPANY_TYPE_RE.match(lines[next_date - 1]):
                details_end = next_date - 2
            elif next_date >= 2 and RESUME_COMPANY_DURATION_RE.match(lines[next_date - 2]):
                details_end = next_date - 3
            else:
                details_end = next_date - 1
        details = lines[details_start:details_end]
        location = ""
        description = []
        for line in details:
            if line.startswith(("\u2022", "-", "\u2013")):
                description.append(line.lstrip("\u2022-\u2013 ").strip())
            elif not location and not description:
                location = line
            elif description:
                description[-1] = f"{description[-1]} {line}"
            else:
                description.append(line)
        entries.append({
            "title": title,
            "company": company,
            "duration": lines[date_index].split(" \u00b7 ")[0].strip(),
            "location": location,
            "description": "\n".join(description),
        })
    return entries


def _parse_resume_education(value):
    lines = [line.strip() for line in _profile_section_text(value).splitlines() if line.strip()]
    anchors = [
        index for index, line in enumerate(lines)
        if RESUME_DATE_RE.match(line)
    ]
    entries = []
    start = 0
    for date_index in anchors:
        details = lines[start:date_index]
        details = [line for line in details if not line.lower().startswith(("grade:", "score:"))]
        if details:
            entry = {"school": details[0]}
            if len(details) > 1:
                entry["degree"] = details[1]
            entry["dates"] = lines[date_index].split(" \u00b7 ")[0].strip()
            for line in lines[start:date_index]:
                if line.lower().startswith("grade:"):
                    entry["score"] = line
                elif line.lower().startswith("score:"):
                    entry["score"] = line
                elif line.lower().startswith("activities and societies:"):
                    entry["extra"] = line
            entries.append(entry)
        start = date_index + 1
        while start < len(lines) and lines[start].lower().startswith(
            ("grade:", "score:", "activities and societies:")
        ):
            if entries:
                entries[-1].setdefault("extra", lines[start])
            start += 1
    return entries


def _resume_section_entries(profile, field):
    value = profile.get(field)
    if not value:
        value = (profile.get("sections") or {}).get(field, "")
    if isinstance(value, dict):
        return [value]
    if isinstance(value, str):
        values = [value]
    elif isinstance(value, (list, tuple)):
        values = list(value)
    else:
        return []

    if field == "experience":
        parsed = _parse_resume_experience(values)
        if parsed:
            return parsed
    elif field == "education":
        parsed = _parse_resume_education(values)
        if parsed:
            return parsed
    return values


def render_resume_html(profile, url, public_url=""):
    """Resume for the applicant: name, location, public profile URL and skills.

    The public /in/ URL is the candidate's own profile link; the talent URL is
    only a fallback for the rare profile that does not expose one.
    """
    name = resume_name(profile) or "Candidate"
    parts = ["<header>", f"<h1>{escape(name)}</h1>"]
    if profile.get("job_title"):
        parts.append(f"<div class='headline'>{escape(profile['job_title'])}</div>")
    location = (profile.get("location") or "").strip()
    if not location:
        location = ", ".join(part.strip() for part in (
            profile.get("city"), profile.get("state"), profile.get("country")
        ) if part and part.strip())
    meta = [item for item in (location, public_url or url) if item]
    if meta:
        parts.append("<div class='meta'>"
                     + "".join(f"<span>{escape(item)}</span>" for item in meta) + "</div>")
    parts.append("</header>")

    for field in ("about", "experience", "education", "honors_and_awards", "publications",
                  "courses", "organizations", "contact_information",
                  "featured", "activity"):
        blocks = profile.get(field)
        if not blocks:
            continue
        if isinstance(blocks, str):
            blocks = [blocks]
        title = "Professional Summary" if field == "about" else field.replace('_', ' ').title()
        parts.append(f"<h2>{escape(title)}</h2>")
        if field == "experience":
            blocks = _resume_section_entries(profile, field)
            for block in blocks:
                if isinstance(block, dict):
                    parts.append(resume_experience_block(block))
                else:
                    parts.append(resume_block(block))
            continue
        if field == "education":
            blocks = _resume_section_entries(profile, field)
            for block in blocks:
                if isinstance(block, dict):
                    school = (block.get("school") or block.get("title") or "").strip()
                    if school:
                        parts.append(
                            f"<h3 class='section-item-title'>"
                            f"{escape(clean_resume_text(school))}</h3>"
                        )
                        block = dict(block)
                        block.pop("school", None)
                        if block.get("title") == school:
                            block.pop("title", None)
                    parts.append(resume_block(block))
                else:
                    parts.append(resume_block(block))
            continue
        for block in blocks:
            parts.append(resume_block(block))

    skills = []
    seen_skills = set()
    for item in profile.get("skills", []):
        value = item.get("skill", "") if isinstance(item, dict) else str(item)
        skill = clean_resume_text(value).strip()
        if skill and skill.casefold() not in seen_skills:
            skills.append(skill)
            seen_skills.add(skill.casefold())
    if skills:
        parts.append("<h2>Skills</h2>")
        parts.append("<div class='skills'>"
                     + "".join(f"<span class='chip'>{escape(skill)}</span>" for skill in skills) + "</div>")

    certifications = profile.get("certifications")
    if certifications:
        parts.append("<h2>Certifications</h2>")
        if isinstance(certifications, str):
            certifications = [certifications]
        for block in certifications:
            if isinstance(block, dict):
                parts.append(resume_certification_block(block))
            else:
                cleaned = clean_resume_text(block)
                if cleaned:
                    parts.append(resume_block(cleaned))

    return ("<!doctype html><html><head><meta charset='utf-8'>"
            f"<title>{escape(name)} - Resume</title><style>{RESUME_CSS}</style></head>"
            f"<body>{''.join(parts)}</body></html>")


async def write_resume_pdf(context, html_doc, path):
    page = await context.new_page()
    try:
        await page.set_content(html_doc, wait_until="load")
        client = await context.new_cdp_session(page)
        try:
            await client.send("Page.enable")
            result = await client.send("Page.printToPDF", {
                "printBackground": True,
                "paperWidth": 8.27, "paperHeight": 11.69,
                "marginTop": 0.55, "marginBottom": 0.55,
                "marginLeft": 0.51, "marginRight": 0.51,
            })
        finally:
            await client.detach()
    finally:
        await page.close()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(base64.b64decode(result["data"]))


async def produce_jobs(api, args, ceipal, jobs, history, job_path, queue, failures):
    """Persist jobs independently of profile processing; never await a profile."""
    stored = 0
    try:
        urls = [args.job_url] if args.job_url else await api.discover_jobs(ceipal, args.jobs_limit)
        for url in urls:
            code = api.job_code_for(url)
            try:
                if not args.search_only and history.get(code, {}).get("status") == "completed":
                    print(f"Job {code} already completed; skipping.", flush=True)
                    continue
                cached = jobs.get(code)
                if not cached:
                    job_args = SimpleNamespace(job_url=url, jd_file=None, location=None)
                    title = await api.job_title(ceipal, job_args)
                    location = await api.job_location(ceipal, job_args)
                    cached = {"url": url, "code": code, "title": title,
                              "location": location, "extracted_at": time.time()}
                    jobs[code] = cached
                    api.save_state(job_path, jobs)
                    print(f"Stored new job: {code} / {title}", flush=True)
                else:
                    print(f"Using cached job: {code}", flush=True)
                queue.put_nowait(dict(cached))
                stored += 1
                print(f"Job collector: {stored} queued; continuing without waiting for profiles.", flush=True)
            except Exception as exc:
                failures.append(code)
                print(f"Job collection failed for {code}: {type(exc).__name__}: {exc}; continuing.", flush=True)
    finally:
        queue.put_nowait(None)
        print(f"Job collection finished: {stored} queued. Profile processing is independent.", flush=True)


async def produce_jobs(api, args, ceipal, jobs, history, job_path, queue, failures):
    stored = 0
    collected_jobs = []
    try:
        urls = [args.job_url] if args.job_url else await api.discover_jobs(ceipal, args.jobs_limit)
        for url in urls:
            code = api.job_code_for(url)
            try:
                if not args.search_only and history.get(code, {}).get("status") == "completed":
                    print(f"Job {code} already completed; skipping.", flush=True)
                    continue
                cached = jobs.get(code)
                if not cached:
                    job_args = SimpleNamespace(job_url=url, jd_file=None, location=None)
                    title = await api.job_title(ceipal, job_args)
                    location = await api.job_location(ceipal, job_args)
                    metadata = getattr(api, "JOB_METADATA", {}).get(url, {})
                    listed_location = metadata.get("location", "")
                    historical_location = (history.get(code) or {}).get("location", "")
                    if not location and listed_location:
                        location = clean_job_location(listed_location)
                    elif not location and historical_location:
                        location = historical_location
                    metadata["location"] = location
                    business_unit = metadata.get("business_unit", "")
                    date_posted = json_safe(metadata.get("date_posted"))
                    cleaned_title = clean_job_title(title)
                    job_index = normalize_job_index(business_unit)
                    cached = {
                        "url": url,
                        "code": code,
                        "title": title,
                        "job_index": job_index,
                        "business_unit": business_unit,
                        "cleaned_title": cleaned_title,
                        "location": location,
                        "date_posted": date_posted,
                        "title_mapping": {title: cleaned_title},
                        "extracted_at": datetime.now().isoformat(),
                    }
                    cached["location_variants"] = api.generate_location_variants(
                        location, business_unit
                    )
                    jobs[code] = cached
                    api.save_state(job_path, jobs)
                    print(f"Stored new job: {code} / {title} / {job_index}", flush=True)
                else:
                    metadata = getattr(api, "JOB_METADATA", {}).get(url, {})
                    changed = False
                    if "business_unit" not in cached:
                        cached["business_unit"] = metadata.get("business_unit", "")
                        changed = True
                    if "date_posted" not in cached:
                        cached["date_posted"] = json_safe(metadata.get("date_posted"))
                        changed = True
                    if not cached.get("cleaned_title") and cached.get("title"):
                        cached["cleaned_title"] = clean_job_title(cached["title"])
                        changed = True
                    if not cached.get("location"):
                        listed_location = metadata.get("location", "")
                        historical_location = (history.get(code) or {}).get("location", "")
                        if listed_location:
                            cached["location"] = listed_location
                            changed = True
                        elif historical_location:
                            cached["location"] = historical_location
                            changed = True
                    cleaned_location = clean_job_location(cached.get("location", "")) if cached.get("location") else ""
                    if cached.get("location") != cleaned_location:
                        cached["location"] = cleaned_location
                        changed = True
                    location_variants = api.generate_location_variants(
                        cached.get("location", ""), cached.get("business_unit", "")
                    )
                    if cached.get("location_variants") != location_variants:
                        cached["location_variants"] = location_variants
                        changed = True
                    normalized_index = normalize_job_index(cached.get("job_index") or cached.get("business_unit"))
                    if cached.get("job_index") != normalized_index:
                        cached["job_index"] = normalized_index
                        changed = True
                    if cached.get("title") and not cached.get("title_mapping"):
                        cached["title_mapping"] = {
                            cached["title"]: cached.get("cleaned_title", cached["title"])
                        }
                        changed = True
                    if changed:
                        jobs[code] = cached
                        api.save_state(job_path, jobs)
                    print(f"Using cached job: {code} / {cached.get('title')} / {cached.get('job_index')}", flush=True)
                collected_jobs.append(dict(cached))
                stored += 1
                print(
                    f"Job collector: {stored} staged; priority queue build pending.",
                    flush=True,
                )
            except Exception as exc:
                failures.append(code)
                print(
                    f"Job collection failed for {code}: {type(exc).__name__}: {exc}; continuing.",
                    flush=True,
                )

        collected_jobs.sort(key=job_sort_key)

        for job in collected_jobs:
            queue.put_nowait(job)
            print(
                f"Queued {job.get('code')} | {job.get('title')} | {job.get('job_index')}",
                flush=True,
            )
    finally:
        queue.put_nowait(None)
        print(
            f"Job collection finished: {stored} staged and queued by priority. Profile processing is independent.",
            flush=True,
        )


async def run(api, args):
    from url import extraction_settings, check_local_model

    provider, model = extraction_settings()
    needs_ai = provider != "none" and not args.search_only and not args.jobs_only
    if needs_ai and provider == "openai" and not os.getenv("OPENAI_API_KEY"):
        raise ValueError("Set OPENAI_API_KEY in .env for profile skill extraction.")
    if needs_ai:
        import pydantic

        if provider == "openai":
            if os.getenv("AI_PROVIDER", "auto").strip().lower() != "auto":
                import openai
        else:
            await asyncio.to_thread(check_local_model, model)

    job_path = api.ROOT / "extract_job.json"
    profile_path = api.ROOT / "profile_data.json"
    history_path = api.ROOT / "job_history.json"
    jobs = read_store(job_path)
    profiles = read_store(profile_path)
    history = read_store(history_path)

    for row in profiles.values():
        if row.get("status") == "saving":
            row["status"] = "review_required"

    def persist():
        api.save_state(profile_path, profiles)

    persist()
    async with api.async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(
            str(api.ROOT / "browser-data-recruit"),
            headless=False,
            accept_downloads=False,
            viewport={"width": 1440, "height": 900},
        )
        context.set_default_timeout(30000)
        try:
            ceipal = context.pages[0] if context.pages else await context.new_page()
            if args.jobs_only:
                await api.login(ceipal, True)
                await ceipal.wait_for_function(
                    "() => !/\\/pages\\/signin|\\/users\\/autologout/.test(location.pathname)",
                    timeout=240000,
                )
                failures = []
                await produce_jobs(api, args, ceipal, jobs, history, job_path, asyncio.Queue(), failures)
                return 1 if failures else 0

            linkedin = await context.new_page()
            await asyncio.gather(api.login(ceipal, True), api.login(linkedin))
            await api.wait_for_sites_ready(ceipal, linkedin)
            queue = asyncio.Queue()
            failures = []

            async def consume_jobs():
                profile_page = await context.new_page()
                applicant_page = await context.new_page()
                while True:
                    job = await queue.get()
                    if job is None:
                        return
                    try:
                        await process_job(
                            api,
                            args,
                            linkedin,
                            profile_page,
                            applicant_page,
                            job,
                            profiles,
                            history,
                            history_path,
                            persist,
                        )
                    except Exception as exc:
                        failures.append(job["code"])
                        print(
                            f"Job {job['code']} incomplete: {type(exc).__name__}: {exc}",
                            flush=True,
                        )

            producer = asyncio.create_task(
                produce_jobs(api, args, ceipal, jobs, history, job_path, queue, failures)
            )
            consumer = asyncio.create_task(consume_jobs())
            try:
                await asyncio.gather(producer, consumer)
            finally:
                for task in (producer, consumer):
                    if not task.done():
                        task.cancel()
                await asyncio.gather(producer, consumer, return_exceptions=True)
                api.save_state(job_path, jobs)
            return 1 if failures else 0
        finally:
            await context.close()


async def process_candidate_profiles(api, args, profile_page, applicant_page, job, urls, profiles, persist):
    from url import build_skill_set

    code = job["code"]
    for url in urls[: args.limit]:
        existing = profiles.get(url)
        row = dict(existing) if existing else {"url": url, "status": "pending", "job_codes": []}
        row["business_unit"] = job.get("business_unit")
        row["job_index"] = job.get("job_index")
        row["job_title"] = job.get("title")
        row["cleaned_job_title"] = job.get("cleaned_title", job.get("title"))
        row["date_posted"] = json_safe(job.get("date_posted"))
        if job.get("title"):
            mappings = dict(row.get("title_mapping") or {})
            mappings[job["title"]] = row.get("cleaned_job_title")
            row["title_mapping"] = mappings

        if code not in row["job_codes"]:
            row["job_codes"].append(code)

        terminal_status = row.get("status") in FINAL
        if terminal_status and (
            row.get("status") == "skipped_linkedin_member"
            or row.get("extraction_version") == PROFILE_EXTRACTION_VERSION
        ):
            profiles[url] = row
            persist()
            continue
        if row.get("status") in UNCERTAIN:
            profiles[url] = row
            persist()
            raise RuntimeError(f"Profile {url} is in uncertain state: {row.get('status')}")

        try:
            needs_refresh = row.get("extraction_version") != PROFILE_EXTRACTION_VERSION
            if not row.get("raw") or needs_refresh:
                row["raw"] = await extract_profile(profile_page, url)
                row["extracted_at"] = datetime.now(timezone.utc).isoformat()
                row["extraction_version"] = PROFILE_EXTRACTION_VERSION
                row.pop("profile", None)
                row["resume_path"] = ""
                if row["raw"].get("public_url"):
                    row["public_url"] = row["raw"]["public_url"]

            if not row.get("profile"):
                row["profile"] = await asyncio.to_thread(build_skill_set, row["raw"])
                row["status"] = "extracted"

            profile = row["profile"]
            if ensure_profile_location(profile, row.get("raw") or {}):
                row["profile"] = profile
                row["status"] = "extracted"
                print(
                    f"    location backfilled for {url}: {profile.get('location')!r}",
                    flush=True,
                )
            if is_linkedin_member_profile(profile):
                row["status"] = "skipped_linkedin_member"
                profiles[url] = row
                persist()
                print(
                    f"    skipped resume/applicant creation for {url}: LinkedIn Member profile",
                    flush=True,
                )
                continue

            if is_currently_in_india(profile, row.get("raw") or {}):
                row["status"] = "skipped_india_location"
                profiles[url] = row
                persist()
                print(
                    f"    skipped resume/applicant creation for {url}: "
                    f"current profile location is India ({profile.get('location')!r})",
                    flush=True,
                )
                continue

            if not Path(row.get("resume_path", "")).is_file():
                target = api.ROOT / "resumes" / resume_filename(profile, url)
                await write_resume_pdf(
                    profile_page.context,
                    render_resume_html(profile, url, row["raw"].get("public_url")),
                    target,
                )
                row["resume_path"] = str(target)
                print(f"    resume written to {target}", flush=True)

            print(
                f"    profile: {profile.get('first_name')} {profile.get('last_name')}"
                f" | city={profile.get('city')!r} state={profile.get('state')!r}"
                f" | skills={len(profile.get('skills', []))}"
                f" | job_index={row.get('job_index')!r}",
                flush=True,
            )

            if terminal_status:
                profiles[url] = row
                persist()
                print(
                    f"    refreshed resume extraction for completed profile {url}; "
                    "applicant was not submitted again.",
                    flush=True,
                )
                continue

            try:
                await create_applicant(applicant_page, row, api, persist, code)
            except TypeError as exc:
                if "positional arguments" not in str(exc):
                    raise
                await create_applicant(applicant_page, row, api, persist)

            row.pop("error", None)
            profiles[url] = row
            persist()

        except Exception as exc:
            if row.get("status") in {"saving", "review_required"}:
                row["status"] = "review_required"
                row["error"] = str(exc)
                profiles[url] = row
                persist()
                print(f"Profile {url}: review required: {exc}", flush=True)
                continue
            profiles.pop(url, None)
            persist()
            print(f"Profile {url}: failed: {exc}", flush=True)
            continue

    return all(
        profiles.get(url, {}).get("status") in FINAL
        for url in urls
    )


async def process_job(api, args, linkedin, profile_page, applicant_page, job, profiles, history, history_path, persist):
    code = job["code"]
    business_unit = job.get("business_unit", "")
    if args.location:
        source_location = api.clean_job_location(args.location.strip())
        location_variants = api.generate_location_variants(source_location, business_unit)
    else:
        source_location = job.get("location", "")
        location_variants = job.get("location_variants") or []
        if not source_location and location_variants:
            source_location = location_variants[0]
    location_variants = list(dict.fromkeys(
        " ".join(str(variant or "").split())
        for variant in location_variants
        if " ".join(str(variant or "").split())
    ))[:3]
    if source_location and not location_variants:
        location_variants = api.generate_location_variants(
            source_location, business_unit
        )
        location_variants = list(dict.fromkeys(
            " ".join(str(variant or "").split())
            for variant in location_variants
            if " ".join(str(variant or "").split())
        ))[:3]

    source_location = " ".join(str(source_location or "").split())
    saved_job = history.get(code, {})
    saved_job["location"] = source_location
    saved_job["location_search_variants"] = location_variants
    history[code] = saved_job
    api.save_state(history_path, history)
    if not source_location or not location_variants:
        raise ValueError(
            f"Job {code} has no location. A job location is required; "
            "LinkedIn search was not started."
        )

    location_searches = saved_job.setdefault("location_searches", [])
    all_urls = []
    for record in location_searches:
        all_urls.extend(record.get("profiles", []))

    legacy_urls = saved_job.get("profiles", []) if not location_searches else []
    if not args.search_only and legacy_urls:
        all_urls.extend(legacy_urls)

    search_title = job.get("cleaned_title") or job["title"]
    search_only_urls = []
    for pass_number, variant in enumerate(location_variants, start=1):
        record = next(
            (item for item in location_searches if item.get("pass") == pass_number),
            None,
        )
        if record and record.get("status") == "completed" and not args.search_only:
            search_only_urls.extend(record.get("profiles", []))
            continue

        if args.search_only:
            candidates = None
        elif record and record.get("status") == "processing":
            candidates = record.get("profiles", [])
        elif pass_number == 1 and legacy_urls:
            candidates = legacy_urls
        else:
            candidates = None

        if candidates is None:
            await linkedin.goto(api.SEARCH_URL, wait_until="domcontentloaded")
            await api.apply_title(linkedin, search_title)
            await api.apply_location(linkedin, variant)
            await api.wait_for_search_results(linkedin)
            candidates = await api.collect_profiles(linkedin, args.limit)

        print(
            f"Job {code}: location search pass {pass_number} using {variant!r} "
            f"returned {len(candidates)} profile(s).",
            flush=True,
        )
        search_only_urls.extend(candidates)
        if args.search_only:
            continue

        if record is None:
            record = {"pass": pass_number, "location": variant}
            location_searches.append(record)
        record["location"] = variant
        record["profiles"] = candidates
        record["status"] = "processing"
        all_urls.extend(candidates)
        saved_job.update({
            "status": "pending",
            "job_url": job.get("url"),
            "job_index": job.get("job_index"),
            "job_title": job.get("title"),
            "location_search_variants": location_variants,
            "profiles": list(dict.fromkeys(all_urls)),
        })
        history[code] = saved_job
        api.save_state(history_path, history)

        profiles_completed = await process_candidate_profiles(
            api, args, profile_page, applicant_page, job, candidates, profiles, persist
        )
        record["status"] = "completed" if profiles_completed else "processing"
        saved_job["profiles"] = list(dict.fromkeys(all_urls))
        api.save_state(history_path, history)

    if args.search_only:
        print(
            f"Search-only: {len(set(search_only_urls))} profile URLs for {code} "
            f"across {len(location_variants)} location pass(es): {location_variants}",
            flush=True,
        )
        return

    unique_urls = list(dict.fromkeys(all_urls))
    if not unique_urls:
        for record in location_searches:
            record["status"] = "pending"
        saved_job["status"] = "pending"
        history[code] = saved_job
        api.save_state(history_path, history)
        raise ValueError("No LinkedIn profiles found in any location search pass; job remains pending.")

    completed_all = (
        all(
            any(item.get("pass") == number and item.get("status") == "completed"
                for item in location_searches)
            for number in range(1, len(location_variants) + 1)
        )
        and all(profiles.get(url, {}).get("status") in FINAL for url in unique_urls)
    )
    if completed_all:
        saved_job["status"] = "completed"
        saved_job["completed_at"] = datetime.now(timezone.utc).isoformat()
        update_job_processing_status(code, 1)
    else:
        saved_job["status"] = "pending"
    saved_job["profiles"] = unique_urls
    saved_job["location_search_variants"] = location_variants
    history[code] = saved_job
    api.save_state(history_path, history)
import json
import unittest
from unittest.mock import patch

import azure_title
import requests


def azure_response(content):
    return {"choices": [{"message": {"content": json.dumps(content)}}]}


class CityLocationValidationTests(unittest.TestCase):
    @patch("azure_title._post_with_retry")
    def test_requires_country_before_calling_ai(self, post):
        self.assertFalse(azure_title.validate_city_location("Toronto, Ontario"))
        post.assert_not_called()

    @patch("azure_title._post_with_retry")
    def test_accepts_city_with_matching_state_and_country(self, post):
        post.return_value = azure_response({"valid": True})

        self.assertTrue(
            azure_title.validate_city_location("Toronto, Ontario, Canada")
        )

    @patch("azure_title._post_with_retry")
    def test_rejects_profile_name_and_degree_as_location(self, post):
        post.return_value = azure_response({"valid": False})

        self.assertFalse(
            azure_title.validate_city_location("Cindy Chiang, PhD")
        )

    @patch("azure_title.time.sleep")
    @patch("azure_title._post_with_retry")
    def test_retries_ai_failure_until_validation_succeeds(self, post, sleep):
        post.side_effect = [
            requests.ConnectionError("temporary connection failure"),
            azure_response({"valid": True}),
        ]

        self.assertTrue(
            azure_title.validate_city_location("Toronto, Ontario, Canada")
        )
        self.assertEqual(post.call_count, 2)
        sleep.assert_called_once_with(azure_title.RETRY_DELAY_SECONDS)

    @patch("azure_title.time.sleep")
    @patch("azure_title._post_with_retry", side_effect=requests.ConnectionError("offline"))
    def test_returns_false_after_ai_retries_are_exhausted(self, post, sleep):
        with patch("azure_title.MAX_RETRIES", 2):
            self.assertFalse(
                azure_title.validate_city_location("Toronto, Ontario, Canada")
            )

        self.assertEqual(post.call_count, 2)
        sleep.assert_called_once_with(azure_title.RETRY_DELAY_SECONDS)

    @patch("azure_title._post_with_retry")
    def test_job_location_cleaning_does_not_run_city_validation(self, post):
        post.return_value = azure_response(
            {"cleaned_location": "Cindy Chiang, PhD"}
        )

        self.assertEqual(
            azure_title.clean_job_location("Cindy Chiang, PhD"),
            "Cindy Chiang, PhD",
        )
        self.assertEqual(post.call_count, 1)


if __name__ == "__main__":
    unittest.main()

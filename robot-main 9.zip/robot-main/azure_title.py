import os
import json
import time
import requests

#azure_ai
AZURE_AI_ENDPOINT = "https://vtazopenai.openai.azure.com/openai/deployments/Job-Posting-Agent-gpt-4.1-mini/chat/completions?api-version=2025-01-01-preview"
AZURE_AI_API_KEY="B6Y7RGeM0MDECfbJU8NIUwsAy0YpBo1GsNuJQ5STQjU0aIIC70hkJQQJ99BIACYeBjFXJ3w3AAABACOG8YlE"
      

MAX_RETRIES = 5
RETRY_DELAY_SECONDS = 5
REQUEST_TIMEOUT_SECONDS = 30


def _post_with_retry(body: dict) -> dict:
    """Call Azure OpenAI with retry handling for 429 rate limits."""
    if not AZURE_AI_ENDPOINT or not AZURE_AI_API_KEY:
        raise ValueError("Missing Azure AI endpoint or API key in environment variables.")

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_AI_API_KEY,
    }

    last_error = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = requests.post(
                AZURE_AI_ENDPOINT,
                headers=headers,
                json=body,
                timeout=REQUEST_TIMEOUT_SECONDS,
            )

            if response.status_code == 429:
                last_error = requests.HTTPError(
                    f"429 Too Many Requests from Azure AI on attempt {attempt}/{MAX_RETRIES}",
                    response=response,
                )
                if attempt < MAX_RETRIES:
                    print(
                        f"Azure AI rate limit hit (attempt {attempt}/{MAX_RETRIES}). "
                        f"Waiting {RETRY_DELAY_SECONDS} seconds before retrying..."
                    )
                    time.sleep(RETRY_DELAY_SECONDS)
                    continue

            response.raise_for_status()
            return response.json()

        except requests.HTTPError as exc:
            last_error = exc
            status_code = getattr(exc.response, "status_code", None)
            if status_code == 429 and attempt < MAX_RETRIES:
                print(
                    f"Azure AI returned 429 (attempt {attempt}/{MAX_RETRIES}). "
                    f"Waiting {RETRY_DELAY_SECONDS} seconds before retrying..."
                )
                time.sleep(RETRY_DELAY_SECONDS)
                continue
            raise
        except requests.RequestException as exc:
            last_error = exc
            raise

    if last_error:
        raise last_error
    raise RuntimeError("Azure AI request failed without a captured exception.")


def _extract_message_content(data: dict) -> str:
    choices = data.get("choices", [])
    if not choices:
        raise ValueError("No response returned from Azure AI.")

    content = choices[0].get("message", {}).get("content", "").strip()
    if not content:
        raise ValueError("Azure AI returned empty content.")

    return content


def validate_city_location(location: str) -> bool:
    """Check that a location names a real city and includes its matching country."""
    candidate = " ".join(str(location or "").split())
    components = [part.strip() for part in candidate.split(",")]
    if len(components) < 2 or not all(components):
        print("City validation (AI): False (country is required; AI not called)")
        return False

    prompt = (
        "Determine whether the supplied location identifies a real city and includes "
        "that city's correct country. The first comma-separated component must be a "
        "geographic city name, not a person's name, degree, job title, or other text. "
        "The last comma-separated component must be the real country containing that "
        "city. If there are middle components, they must be the matching state or "
        "province. Return valid=true only when the city, any state/province, and "
        "country are consistent and you are confident. If the country is missing, "
        "uncertain, or any component is not a real geographic location, return "
        "valid=false. "
        "Return JSON only with a boolean key named valid."
    )
    body = {
        "messages": [
            {"role": "system", "content": prompt},
            {"role": "user", "content": json.dumps({"location": candidate}, ensure_ascii=False)},
        ],
        "temperature": 0,
        "max_tokens": 30,
        "response_format": {"type": "json_object"},
    }

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            data = _post_with_retry(body)
            content = _extract_message_content(data)
            try:
                parsed = json.loads(content)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Azure AI returned non-JSON location validation content: {content}"
                ) from exc

            valid = parsed.get("valid")
            if not isinstance(valid, bool):
                raise ValueError(
                    f"Azure AI returned an invalid location validation result: {content}"
                )

            print(f"City validation (AI): {valid}")
            return valid
        except (requests.RequestException, ValueError, RuntimeError) as exc:
            if attempt == MAX_RETRIES:
                print(
                    "City validation (AI): False "
                    f"(failed after {MAX_RETRIES} attempts: {exc})"
                )
                return False
            print(
                f"City validation AI attempt {attempt}/{MAX_RETRIES} failed: {exc}. "
                f"Retrying in {RETRY_DELAY_SECONDS} seconds..."
            )
            time.sleep(RETRY_DELAY_SECONDS)

    return False


def clean_job_title(raw_title: str) -> str:
    """Return a cleaned job title in maximum 2 words."""
    if raw_title is None:
        return ""

    original = " ".join(str(raw_title).split())
    if not original:
        return ""

    prompt = (
        "You clean messy job titles extracted from ATS, LinkedIn, or job boards. "
        "Return JSON only with keys original_title and cleaned_title. "
        "Preserve the main role meaning. "
        "Fix casing, spacing, punctuation, and expand acronyms only when very clear. "
        "Remove level indicators like L2, L3, II, III, Level 2, Level 3, numeric grades, and extra noise. "
        "Return the cleaned_title in STRICTLY maximum 2 words only. "
        "Do not return more than 2 words."
    )

    body = {
        "messages": [
            {"role": "system", "content": prompt},
            {"role": "user", "content": json.dumps({"original_title": original}, ensure_ascii=False)},
        ],
        "temperature": 0,
        "max_tokens": 60,
        "response_format": {"type": "json_object"},
    }

    data = _post_with_retry(body)
    content = _extract_message_content(data)

    try:
        parsed = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Azure AI returned non-JSON content: {content}") from exc

    cleaned = " ".join(str(parsed.get("cleaned_title", "")).split())
    cleaned_words = cleaned.split()[:2]
    return " ".join(cleaned_words) if cleaned_words else original


def clean_job_location(raw_location: str) -> str:
    """Return a cleaned location with country always included."""
    if raw_location is None:
        return ""

    original = " ".join(str(raw_location).split())
    if not original:
        return ""

    prompt = (
        "You are an expert location cleaning agent. Your task is to take raw, messy location data and convert it into a clean, fully expanded, and standardized format. "
        "Strictly follow these rules: "
        "1. Always return full location names. Never use abbreviations or short forms. For example, use California instead of CA, Virginia instead of VA, and United States instead of US or USA. "
        "2. Always include the country in the final output whenever it is present or can be clearly inferred from the input. "
        "3. Format the cleaned location as comma-separated components: City, State or Province, Country. "
        "Omit components that are not present and do not guess missing cities or states. "
        "4. Remove noise such as Remote, Hybrid, Onsite, Location:, job IDs, extra punctuation, and duplicate text. "
        "5. Preserve the true location and do not invent details unless the country is obvious from the city and state combination. "
        "6. If the input is a U.S. city and state, always return United States as the country. "
        "7. Return JSON only with keys original_location and cleaned_location. Do not return any extra text."
    )

    body = {
        "messages": [
            {"role": "system", "content": prompt},
            {"role": "user", "content": json.dumps({"original_location": original}, ensure_ascii=False)},
        ],
        "temperature": 0,
        "max_tokens": 80,
        "response_format": {"type": "json_object"},
    }

    data = _post_with_retry(body)
    content = _extract_message_content(data)

    try:
        parsed = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Azure AI returned non-JSON content: {content}") from exc

    cleaned = " ".join(str(parsed.get("cleaned_location", "")).split())
    return cleaned or original
import unittest
from profile_rules import build_profile


class RuleTests(unittest.TestCase):
    def test_skills_and_header_location_without_job_address_leak(self):
        result = build_profile({"public_sections": [
            "John Callum McDaniel\nSchool · Richmond, Virginia, United States · Industry\n"
            "Experience\nPosition title\nSecurity Analyst\nPosition location\nBoston, Massachusetts, United States\n"
            "Position summary\nWork across governance, risk, and compliance.\n"
            "Skills (3)\nUnusual Tool\nTeamwork\nShow all 3 skills\nInterests\nUnrelated Person"]})
        self.assertEqual(result["first_name"], "John Callum")
        self.assertEqual(result["last_name"], "McDaniel")
        self.assertEqual(result["city"], "Richmond")
        self.assertEqual(result["job_title"], "Security Analyst")
        self.assertEqual([s["skill"] for s in result["skills"]],
                         ["Unusual Tool", "Teamwork", "governance", "risk", "compliance"])

    def test_school_segment_is_not_mistaken_for_the_location(self):
        result = build_profile({"public_sections": [
            "Rodney Daniels\nSenior Security Architect\n"
            "University of Maryland, Global Campus (Cum Laude, 2009) \u00b7 "
            "Richmond, Virginia, United States \u00b7 Computer and Network Security \u00b7 319\n"
            "319 connections\nExperience\nPosition title\nSecurity Engineer"]})
        self.assertEqual(result["city"], "Richmond")
        self.assertEqual(result["state"], "Virginia")

    def test_rejects_person_name_and_degree_as_city_and_state(self):
        result = build_profile({"public_sections": [
            "Suresh Kotturi\nSenior Consultant\n"
            "Suresh Kotturi, B.Comm, United States\nExperience\nPosition title\nAnalyst"
        ]})
        self.assertIsNone(result["city"])
        self.assertIsNone(result["state"])

    def test_city_must_be_at_most_18_characters(self):
        from profile_rules import is_valid_city_name

        self.assertTrue(is_valid_city_name("A"))
        self.assertTrue(is_valid_city_name("Toronto"))
        self.assertTrue(is_valid_city_name("Alpharetta"))
        self.assertTrue(is_valid_city_name("abcdefghijklmnop"))
        self.assertTrue(is_valid_city_name("abcdefghijklmnopqr"))
        self.assertTrue(is_valid_city_name("München"))
        self.assertTrue(is_valid_city_name("New York"))
        self.assertTrue(is_valid_city_name("San Francisco"))
        self.assertTrue(is_valid_city_name("Salt Lake City"))
        self.assertFalse(is_valid_city_name("123456789012345678"))
        self.assertFalse(is_valid_city_name("abcdefghijklmnopqrs"))

    def test_profile_header_extracts_two_word_city_and_country(self):
        result = build_profile({"public_sections": [
            "Jane Doe\nNew York, New York, United States\nExperience\nPosition title\nAnalyst"
        ]})
        self.assertEqual(result["city"], "New York")
        self.assertEqual(result["country"], "United States")

    def test_does_not_invent_skills_from_certification(self):
        result = build_profile({"public_sections": ["SingleName\nCertifications\nEXAM-123\nIssuer"]})
        self.assertIsNone(result["last_name"])
        self.assertEqual(result["skills"], [])
        self.assertEqual(result["certifications"], ["EXAM-123\nIssuer"])


if __name__ == "__main__":
    unittest.main()
